-- Career Hub Database Schema
-- Import this file in phpMyAdmin or run: mysql -u root -p < database.sql

CREATE DATABASE IF NOT EXISTS career_hub CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE career_hub;

-- =============================================
-- STUDENTS
-- =============================================
CREATE TABLE IF NOT EXISTS students (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  initials VARCHAR(10) DEFAULT '',
  age INT DEFAULT NULL,
  location VARCHAR(100) DEFAULT '',
  resume_url VARCHAR(255) DEFAULT '',
  profile_pic VARCHAR(255) DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =============================================
-- EMPLOYERS
-- =============================================
CREATE TABLE IF NOT EXISTS employers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  company_name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  industry VARCHAR(100) DEFAULT '',
  website VARCHAR(255) DEFAULT '',
  description TEXT DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =============================================
-- SKILLS
-- =============================================
CREATE TABLE IF NOT EXISTS skills (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  name VARCHAR(50) NOT NULL,
  category VARCHAR(50) DEFAULT 'Other',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =============================================
-- CERTIFICATIONS
-- =============================================
CREATE TABLE IF NOT EXISTS certifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  title VARCHAR(150) NOT NULL,
  issuer VARCHAR(100) NOT NULL,
  issue_date DATE DEFAULT NULL,
  cert_url VARCHAR(255) DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =============================================
-- PROJECTS
-- =============================================
CREATE TABLE IF NOT EXISTS projects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  title VARCHAR(150) NOT NULL,
  description TEXT DEFAULT '',
  tech_stack VARCHAR(255) DEFAULT '',
  project_url VARCHAR(500) DEFAULT NULL,
  project_date DATE DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =============================================
-- QUIZ SCORES
-- =============================================
CREATE TABLE IF NOT EXISTS quiz_scores (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  domain VARCHAR(20) NOT NULL,
  score INT NOT NULL,
  taken_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  UNIQUE KEY unique_quiz (student_id, domain)
) ENGINE=InnoDB;

-- =============================================
-- INTERNSHIPS
-- =============================================
CREATE TABLE IF NOT EXISTS internships (
  id INT AUTO_INCREMENT PRIMARY KEY,
  employer_id INT NOT NULL,
  title VARCHAR(150) NOT NULL,
  company_name VARCHAR(100) NOT NULL,
  domain VARCHAR(20) NOT NULL,
  duration VARCHAR(50) NOT NULL,
  stipend INT DEFAULT 0,
  skills VARCHAR(255) DEFAULT '',
  description TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (employer_id) REFERENCES employers(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =============================================
-- APPLICATIONS
-- =============================================
CREATE TABLE IF NOT EXISTS applications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  internship_id INT NOT NULL,
  status ENUM('Pending','Accepted','Rejected') DEFAULT 'Pending',
  cover_letter TEXT DEFAULT '',
  phone VARCHAR(30) DEFAULT '',
  expected_salary INT DEFAULT NULL,
  selected_project_ids VARCHAR(255) DEFAULT '',
  selected_cert_ids VARCHAR(255) DEFAULT '',
  applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY (internship_id) REFERENCES internships(id) ON DELETE CASCADE,
  UNIQUE KEY unique_application (student_id, internship_id)
) ENGINE=InnoDB;

-- Run these if the table already exists and columns are missing:
-- ALTER TABLE applications ADD COLUMN IF NOT EXISTS cover_letter TEXT DEFAULT '';
-- ALTER TABLE applications ADD COLUMN IF NOT EXISTS phone VARCHAR(30) DEFAULT '';
-- ALTER TABLE applications ADD COLUMN IF NOT EXISTS expected_salary INT DEFAULT NULL;
-- ALTER TABLE applications ADD COLUMN IF NOT EXISTS selected_project_ids VARCHAR(255) DEFAULT '';
-- ALTER TABLE applications ADD COLUMN IF NOT EXISTS selected_cert_ids VARCHAR(255) DEFAULT '';

-- =============================================
-- DEMO DATA
-- =============================================


