// ===================== AUTH CHECK =====================
(async function() {
  try {
    const r = await fetch('../php/auth.php', {
      credentials: 'include',
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ action: 'check_session', type: 'student' })
    });
    const d = await r.json();
    if (!d.success) window.location.href = '../student/login.html';
    else {
      loadDashboard();
      // Auto-refresh application status every 30 seconds (for employer accept/reject updates)
      setInterval(async () => {
        try {
          const res = await api('get_applications');
          if (res && res.success) {
            applications = res.applications;
            renderApps();
          }
        } catch(e) {}
      }, 30000);
    }
  } catch(e) {
    window.location.href = '../student/login.html';
  }
})();

function logout() {
  fetch('../php/auth.php', {
    credentials: 'include',
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ action: 'logout' })
  }).then(() => window.location.href = '../index.html');
}

// ===================== DATA STATE =====================
let profile = {};
let skills = [];
let certs = [];
let projects = [];
let quizScores = {};
let internships = [];
let applications = [];
let pendingInternId = null;
let recentActivity = [];
let notifications = [];

// Escapes user-supplied text before it is inserted as HTML, to prevent
// stored XSS (e.g. an employer putting "<script>" in an internship title
// or description, which would otherwise run in the student's browser).
function escHtml(s) {
  return String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

// Only allow http(s) links to be rendered as real hrefs - blocks
// javascript: URIs and other unsafe schemes stored in project/cert URLs.
function safeUrl(u) {
  if (!u) return '';
  const s = String(u).trim();
  return /^https?:\/\//i.test(s) ? s : '';
}

// Reads the CSRF token cookie set by php/db.php (double-submit pattern).
// The backend compares this against the value stored in the PHP session.
function getCsrfToken() {
  const m = document.cookie.match(/(?:^|;\s*)ch_csrf=([^;]+)/);
  return m ? decodeURIComponent(m[1]) : '';
}

function api(action, params = {}) {
  const fd = new URLSearchParams({ action, csrf_token: getCsrfToken(), ...params });
  return fetch('../php/student-api.php', {
    credentials: 'include',
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: fd
  }).then(r => r.json());
}

async function safeApi(action, params = {}) {
  try { return await api(action, params); } catch(e) { return { success: false }; }
}

async function loadDashboard() {
  try {
  const [p, s, c, pr, q, i, a, st, ra, notifRes] = await Promise.all([
    safeApi('get_profile'),
    safeApi('get_skills'),
    safeApi('get_certs'),
    safeApi('get_projects'),
    safeApi('get_quiz_scores'),
    safeApi('get_internships'),
    safeApi('get_applications'),
    safeApi('get_stats'),
    safeApi('get_recent_activity'),
    safeApi('get_notifications')
  ]);

  if (p.success) profile = p.profile;
  if (s.success) skills = s.skills;
  if (c.success) certs = c.certs;
  if (pr.success) projects = pr.projects;
  if (q.success) quizScores = q.scores;
  if (i.success) internships = i.internships;
  if (a.success) applications = a.applications;
  if (ra.success) recentActivity = ra.activity || [];
  if (notifRes.success) notifications = notifRes.notifications || [];

  // Header
  const firstName = (profile.full_name || 'Student').split(' ')[0];
  document.getElementById('sn-uname').textContent = profile.full_name || 'Student';
  document.getElementById('s-greet').textContent = firstName;
  document.getElementById('s-av').textContent = profile.initials || firstName.slice(0,2).toUpperCase();
  // Time-based greeting
  const hr = new Date().getHours();
  const greetWord = hr < 12 ? 'Good morning' : hr < 17 ? 'Good afternoon' : 'Good evening';
  const greetEl = document.querySelector('#s-home .pg-title');
  if (greetEl) greetEl.innerHTML = greetWord + ', <span id="s-greet">' + firstName + '</span> &#128075;';

  // Stats
  if (st && st.success && st.stats) {
    document.getElementById('h-skills-ct').textContent = st.stats.skills ?? 0;
    document.getElementById('h-cert-ct').textContent = st.stats.certs ?? 0;
    document.getElementById('h-app-ct').textContent = st.stats.applications ?? 0;
    document.getElementById('h-best-score').textContent = st.stats.best_score ?? '—';
  }

  // Profile form
  document.getElementById('pf-name').value = profile.full_name || '';
  document.getElementById('pf-email').value = profile.email || '';
  document.getElementById('pf-age').value = profile.age || '';
  document.getElementById('pf-loc').value = profile.location || '';
  document.getElementById('pf-resume').value = profile.resume_url || '';
  document.getElementById('pf-pic').value = profile.profile_pic || '';
  document.getElementById('p-disp-name').textContent = profile.full_name || '...';
  document.getElementById('p-disp-email').textContent = profile.email || '...';
  document.getElementById('p-disp-loc').textContent = profile.location || '...';

  renderFeatured();
  renderRecentActivity();
  renderNotifInternships();
  renderNotifications();
  renderSkills();
  renderCerts();
  renderProjects();
  renderBrowse();
  renderApps();
  updateQStatus();
  } catch(err) {
    console.error('Dashboard load error:', err);
  }
}

// ===================== NAVIGATION =====================
function sPg(pgId, navId) {
  document.querySelectorAll('#s-home, #s-profile, #s-skills, #s-certs, #s-projects, #s-applied, #s-quiz-sel, #s-quiz-active, #s-quiz-result, #s-intern, #s-notif').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById(pgId).classList.add('active');
  document.getElementById(navId).classList.add('active');

  if (pgId === 's-profile') {
    // Refresh profile display
    document.getElementById('p-disp-name').textContent = profile.full_name || '...';
    document.getElementById('p-disp-email').textContent = profile.email || '...';
    document.getElementById('p-disp-loc').textContent = profile.location || '...';
    document.getElementById('s-av').textContent = profile.initials || (profile.full_name || 'ST').slice(0,2).toUpperCase();
    renderProfileCerts();
    renderProfileProjects();
  }
  if (pgId === 's-skills') renderSkills();
  if (pgId === 's-intern') { renderNotifInternships(); }
  if (pgId === 's-notif') { renderNotifications(); }
  if (pgId === 's-certs') renderCerts();
  if (pgId === 's-projects') renderProjects();
  if (pgId === 's-applied') renderApps();
  if (pgId === 's-quiz-sel') updateQStatus();
}

// ===================== PROFILE =====================
async function saveProfile() {
  const name = document.getElementById('pf-name').value;
  const email = document.getElementById('pf-email').value;
  const age = document.getElementById('pf-age').value;
  const loc = document.getElementById('pf-loc').value;
  const resume = document.getElementById('pf-resume').value;
  const pic = document.getElementById('pf-pic').value;

  const res = await api('update_profile', { full_name: name, email, age, location: loc, resume_url: resume, profile_pic: pic });
  if (res.success) {
    profile.full_name = name;
    profile.email = email;
    profile.age = age;
    profile.location = loc;
    profile.initials = name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
    document.getElementById('sn-uname').textContent = name;
    document.getElementById('s-greet').textContent = name.split(' ')[0];
    document.getElementById('s-av').textContent = profile.initials;
    document.getElementById('p-disp-name').textContent = name;
    document.getElementById('p-disp-email').textContent = email;
    document.getElementById('p-disp-loc').textContent = loc;
    const msg = document.getElementById('p-save-msg');
    msg.style.display = 'block';
    setTimeout(() => msg.style.display = 'none', 2500);
  }
}

// ===================== PROFILE PAGE: CERTS & PROJECTS PREVIEW =====================
function renderProfileCerts() {
  const el = document.getElementById('pf-certs-preview');
  if (!el) return;
  if (!certs.length) { el.innerHTML = '<p class="text-muted" style="font-size:13px;margin:0;">No certifications yet. <a style="color:var(--blue);cursor:pointer;" onclick="sPg(\'s-certs\',\'sn-certs\')">Add one &rarr;</a></p>'; return; }
  el.innerHTML = certs.map(c => {
    const url = safeUrl(c.cert_url);
    return `<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--border);">
      <div><div style="font-weight:500;font-size:14px;">${escHtml(c.title)}</div><div style="font-size:12px;color:var(--muted);">Issued by ${escHtml(c.issuer)}${c.issue_date ? ' &middot; ' + escHtml(c.issue_date) : ''}</div></div>
      ${url ? `<a href="${url}" target="_blank" rel="noopener noreferrer" class="btn sm blue" style="font-size:11px;">View &#8599;</a>` : ''}
    </div>`;
  }).join('');
}

function renderProfileProjects() {
  const el = document.getElementById('pf-projects-preview');
  if (!el) return;
  if (!projects.length) { el.innerHTML = '<p class="text-muted" style="font-size:13px;margin:0;">No projects yet. <a style="color:var(--blue);cursor:pointer;" onclick="sPg(\'s-projects\',\'sn-projects\')">Add one &rarr;</a></p>'; return; }
  el.innerHTML = projects.map(p =>
    `<div style="border:1.5px solid var(--border);border-radius:9px;padding:12px;margin-bottom:8px;">
      <div style="font-weight:600;font-size:14px;margin-bottom:4px;">${escHtml(p.title)}</div>
      ${p.description ? `<div style="font-size:13px;color:var(--muted);margin-bottom:6px;">${escHtml(p.description)}</div>` : ''}
      <div>${(p.tech_stack || '').split(',').filter(Boolean).map(x => `<span class="tag teal" style="font-size:11px;">${escHtml(x.trim())}</span>`).join(' ')}</div>
    </div>`
  ).join('');
}

// ===================== SKILLS =====================
function renderSkills() {
  const el = document.getElementById('skills-tags');
  if (!skills.length) { el.innerHTML = '<span class="text-muted">No skills yet. Add your first skill!</span>'; return; }
  el.innerHTML = skills.map((s, i) =>
    `<span class="tag blue" style="font-size:13px; padding:5px 14px; cursor:default;">${escHtml(s.name)} <span style="opacity:0.65; font-size:11px;">${escHtml(s.category)}</span>
    <button onclick="deleteSkill(${s.id}, ${i})" style="background:none; border:none; cursor:pointer; margin-left:6px; color:inherit; opacity:0.6; font-size:13px; padding:0;">&#215;</button></span>`
  ).join('');
}

async function addSkill() {
  const n = document.getElementById('mi-skill').value.trim();
  const c = document.getElementById('mi-skill-cat').value;
  if (!n) return;
  const res = await api('add_skill', { name: n, category: c });
  if (res.success) {
    const refresh = await api('get_skills');
    skills = refresh.skills;
    document.getElementById('mi-skill').value = '';
    closeM('m-skill');
    renderSkills();
    loadStats();
  }
}

async function deleteSkill(id, idx) {
  const res = await api('delete_skill', { id });
  if (res.success) {
    const refresh = await api('get_skills');
    skills = refresh.skills;
    renderSkills();
    loadStats();
  }
}

// ===================== CERTIFICATIONS =====================
function renderCerts() {
  const el = document.getElementById('certs-list');
  if (!certs.length) { el.innerHTML = '<p class="text-muted">No certifications yet.</p>'; return; }
  el.innerHTML = certs.map((c, i) =>
    `<div class="flex justify-between items-center" style="padding:12px 0; border-bottom:1px solid var(--border);">
      <div><div class="fw-500">${escHtml(c.title)}</div><div class="text-sm text-muted mt-4">Issued by ${escHtml(c.issuer)}${c.issue_date ? ' &middot; ' + escHtml(c.issue_date) : ''}</div></div>
      <button class="btn sm red" onclick="deleteCert(${c.id}, ${i})">Remove</button>
    </div>`
  ).join('');
}

async function addCert() {
  const t = document.getElementById('mi-ct').value.trim();
  const i = document.getElementById('mi-ci').value.trim();
  if (!t || !i) return;
  const res = await api('add_cert', { title: t, issuer: i, issue_date: document.getElementById('mi-cd').value, cert_url: document.getElementById('mi-cu').value });
  if (res.success) {
    const refresh = await api('get_certs');
    certs = refresh.certs;
    closeM('m-cert');
    renderCerts();
    loadStats();
  }
}

async function deleteCert(id, idx) {
  const res = await api('delete_cert', { id });
  if (res.success) {
    const refresh = await api('get_certs');
    certs = refresh.certs;
    renderCerts();
    loadStats();
  }
}

// ===================== PROJECTS =====================
function renderProjects() {
  const el = document.getElementById('proj-list');
  if (!projects.length) { el.innerHTML = '<p class="text-muted">No projects yet. Add your first project!</p>'; return; }
  el.innerHTML = projects.map((p, i) => {
    const url = safeUrl(p.project_url);
    return `<div class="intern-card">
      <div class="flex justify-between items-center mb-8">
        <div class="ic-title" style="margin:0;">${escHtml(p.title)}</div>
        <div style="display:flex;gap:6px;align-items:center;">
          ${url ? `<a href="${url}" target="_blank" rel="noopener noreferrer" class="btn sm blue" style="font-size:11px;">View &#8599;</a>` : ''}
          <button class="btn sm red" onclick="deleteProject(${p.id}, ${i})">Remove</button>
        </div>
      </div>
      <p class="text-muted" style="font-size:13px; line-height:1.6; margin-bottom:10px;">${escHtml(p.description || '')}</p>
      <div>${(p.tech_stack || '').split(',').filter(Boolean).map(x => `<span class="tag teal">${escHtml(x.trim())}</span>`).join(' ')}</div>
    </div>`;
  }).join('');
}

async function addProject() {
  const t = document.getElementById('mi-pt').value.trim();
  if (!t) return;
  const res = await api('add_project', { title: t, description: document.getElementById('mi-pd').value, tech_stack: document.getElementById('mi-ps').value, project_url: document.getElementById('mi-purl-main').value, project_date: document.getElementById('mi-pdate').value });
  if (res.success) {
    const refresh = await api('get_projects');
    projects = refresh.projects;
    closeM('m-proj');
    renderProjects();
  }
}

async function deleteProject(id, idx) {
  const res = await api('delete_project', { id });
  if (res.success) {
    const refresh = await api('get_projects');
    projects = refresh.projects;
    renderProjects();
  }
}

// ===================== BROWSE / FEATURED =====================
function renderBrowse() {
  const el = document.getElementById('browse-list');
  const q = (document.getElementById('s-search')?.value || '').toLowerCase();
  const dom = document.getElementById('s-filter')?.value || '';
  const list = internships.filter(i =>
    (!q || i.title.toLowerCase().includes(q) || i.domain.toLowerCase().includes(q)) &&
    (!dom || i.domain === dom)
  );
  if (!list.length) { el.innerHTML = '<p class="text-muted center" style="padding:2rem;">No internships found matching your search.</p>'; return; }
  el.innerHTML = list.map(i => {
    const qual = (quizScores[i.domain] || 0) >= 80;
    const applied = applications.some(a => a.internship_id == i.id);
    return `<div class="intern-card">
      <div class="ic-company">${escHtml(i.company_name)}</div>
      <div class="ic-title">${escHtml(i.title)}</div>
      <div class="ic-meta">
        <span>&#128197; ${escHtml(i.duration)}</span>
        <span>&#128188; ${escHtml(i.domain)}</span>
        <span class="ic-stipend">PKR ${parseInt(i.stipend).toLocaleString()}/month</span>
        <span>&#128101; ${i.applicant_count || 0} applied</span>
      </div>
      <div class="ic-desc">${escHtml(i.description)}</div>
      <div class="ic-skills">${i.skills.split(',').map(s => `<span class="tag gray">${escHtml(s.trim())}</span>`).join(' ')}</div>
      <div class="ic-actions">
        ${applied
          ? '<span class="tag green">&#10003; Applied</span>'
          : qual
            ? `<button class="btn sm blue" onclick="openApply(${i.id})">Apply Now</button><span class="tag green">Quiz passed &#10003;</span>`
            : `<button class="btn sm" onclick="startQuiz('${i.domain}')">Take ${escHtml(i.domain)} Quiz first</button><span class="tag amber">Score 80%+ required</span>`}
      </div>
    </div>`;
  }).join('');
}

function renderFeatured() {
  document.getElementById('featured-list').innerHTML = internships.slice(0, 2).map(i => {
    const qual = (quizScores[i.domain] || 0) >= 80;
    return `<div class="intern-card">
      <div class="ic-company">${escHtml(i.company_name)}</div>
      <div class="ic-title">${escHtml(i.title)}</div>
      <div class="ic-meta"><span>&#128197; ${escHtml(i.duration)}</span><span>&#128188; ${escHtml(i.domain)}</span><span class="ic-stipend">PKR ${parseInt(i.stipend).toLocaleString()}/month</span></div>
      <div class="ic-actions">
        ${qual ? `<button class="btn sm blue" onclick="openApply(${i.id})">Apply Now</button>` : `<button class="btn sm" onclick="startQuiz('${i.domain}')">Take ${escHtml(i.domain)} Quiz</button>`}
      </div>
    </div>`;
  }).join('');
}

// ===================== APPLICATIONS =====================
function renderApps() {
  const el = document.getElementById('apps-tbody');
  if (!applications.length) { el.innerHTML = '<tr><td colspan="4" class="text-muted center" style="padding:2rem;">No applications yet.</td></tr>'; return; }
  const colorMap = { Pending: 'blue', Accepted: 'green', Rejected: 'red', 'Not Eligible': 'amber' };
  el.innerHTML = applications.map(a => `<tr>
    <td class="fw-500">${escHtml(a.intern_title)}</td>
    <td>${escHtml(a.company_name)}</td>
    <td>${escHtml(a.applied_at)}</td>
    <td><span class="tag ${colorMap[a.status] || 'gray'}">${escHtml(a.status)}</span></td>
  </tr>`).join('');
}

async function openApply(id) {
  pendingInternId = id;
  const intern = internships.find(i => i.id == id);
  if (!intern) return;
  const qual = (quizScores[intern.domain] || 0) >= 80;

  document.getElementById('ma-title').textContent = 'Apply: ' + intern.title;
  document.getElementById('ma-sub').textContent = intern.company_name + ' · ' + intern.domain + ' · PKR ' + parseInt(intern.stipend).toLocaleString() + '/month';

  const quizDiv = document.getElementById('ma-quiz-required');
  const formDiv = document.getElementById('ma-form');

  if (!qual) {
    quizDiv.style.display = '';
    formDiv.style.display = 'none';
    document.getElementById('ma-quiz-domain').textContent = intern.domain;
    document.getElementById('ma-goto-quiz').onclick = function() {
      closeM('m-apply');
      startQuiz(intern.domain);
    };
  } else {
    quizDiv.style.display = 'none';
    formDiv.style.display = '';

    // Pre-fill personal info
    document.getElementById('maf-name').value   = profile.full_name || '';
    document.getElementById('maf-email').value  = profile.email || '';
    document.getElementById('maf-phone').value  = '';
    document.getElementById('maf-reason').value = '';
    document.getElementById('ma-form-err').style.display = 'none';

    // Hide inline forms
    const pf = document.getElementById('ma-proj-form');
    const cf = document.getElementById('ma-cert-form');
    if (pf) pf.style.display = 'none';
    if (cf) cf.style.display = 'none';

    // Render projects checklist (pre-check all existing)
    renderModalProjects();
    renderModalCerts();
  }
  openM('m-apply');
}

function renderModalProjects() {
  const projEl = document.getElementById('ma-project-list');
  if (!projEl) return;
  if (!projects.length) {
    projEl.innerHTML = '<div style="color:var(--muted);font-size:13px;padding:4px;">No projects yet. Click "+ Add New" above to add one.</div>';
  } else {
    projEl.innerHTML = projects.map(p =>
      '<label style="display:flex;align-items:flex-start;gap:8px;cursor:pointer;padding:6px 4px;">' +
      '<input type="checkbox" class="ma-proj-chk" value="' + p.id + '" checked style="margin-top:2px;width:15px;height:15px;flex-shrink:0;cursor:pointer;" />' +
      '<div><div style="font-weight:500;font-size:13px;">' + escHtml(p.title) + '</div>' +
      (p.tech_stack ? '<div style="font-size:11px;color:var(--muted);">' + escHtml(p.tech_stack) + '</div>' : '') +
      '</div></label>'
    ).join('');
  }
}

function renderModalCerts() {
  const certEl = document.getElementById('ma-cert-list');
  if (!certEl) return;
  if (!certs.length) {
    certEl.innerHTML = '<div style="color:var(--muted);font-size:13px;padding:4px;">No certificates yet. Click "+ Add New" above to add one.</div>';
  } else {
    certEl.innerHTML = certs.map(c =>
      '<label style="display:flex;align-items:flex-start;gap:8px;cursor:pointer;padding:6px 4px;">' +
      '<input type="checkbox" class="ma-cert-chk" value="' + c.id + '" checked style="margin-top:2px;width:15px;height:15px;flex-shrink:0;cursor:pointer;" />' +
      '<div><div style="font-weight:500;font-size:13px;">' + escHtml(c.title) + '</div>' +
      '<div style="font-size:11px;color:var(--muted);">' + escHtml(c.issuer) + (c.issue_date ? ' · ' + escHtml(c.issue_date) : '') + '</div>' +
      '</div></label>'
    ).join('');
  }
}

function toggleInlineForm(id) {
  const el = document.getElementById(id);
  if (!el) return;
  el.style.display = el.style.display === 'none' ? '' : 'none';
}

async function inlineAddProject() {
  const t = document.getElementById('ma-pt').value.trim();
  const s = document.getElementById('ma-ps').value.trim();
  const d = document.getElementById('ma-pd').value.trim();
  const u = document.getElementById('ma-purl') ? document.getElementById('ma-purl').value.trim() : '';
  const errEl = document.getElementById('ma-proj-form-err');
  if (!t) { errEl.textContent = 'Title is required.'; errEl.style.display = ''; return; }
  errEl.style.display = 'none';
  const res = await api('add_project', { title: t, tech_stack: s, description: d, project_url: u });
  if (res.success) {
    const refresh = await api('get_projects');
    projects = refresh.projects;
    renderProjects();
    // Clear form fields
    document.getElementById('ma-pt').value = '';
    document.getElementById('ma-ps').value = '';
    document.getElementById('ma-pd').value = '';
    if (document.getElementById('ma-purl')) document.getElementById('ma-purl').value = '';
    document.getElementById('ma-proj-form').style.display = 'none';
    renderModalProjects();
  } else {
    errEl.textContent = res.error || 'Failed to add project.';
    errEl.style.display = '';
  }
}

async function inlineAddCert() {
  const t  = document.getElementById('ma-ct').value.trim();
  const is = document.getElementById('ma-ci').value.trim();
  const d  = document.getElementById('ma-cd').value;
  const u  = document.getElementById('ma-cu').value.trim();
  const errEl = document.getElementById('ma-cert-form-err');
  if (!t || !is) { errEl.textContent = 'Title and issuer are required.'; errEl.style.display = ''; return; }
  errEl.style.display = 'none';
  const res = await api('add_cert', { title: t, issuer: is, issue_date: d, cert_url: u });
  if (res.success) {
    const refresh = await api('get_certs');
    certs = refresh.certs;
    renderCerts();
    // Clear form fields
    document.getElementById('ma-ct').value = '';
    document.getElementById('ma-ci').value = '';
    document.getElementById('ma-cd').value = '';
    document.getElementById('ma-cu').value = '';
    document.getElementById('ma-cert-form').style.display = 'none';
    renderModalCerts();
  } else {
    errEl.textContent = res.error || 'Failed to add certificate.';
    errEl.style.display = '';
  }
}

function showToast(msg, color) {
  const t = document.getElementById('toast-msg');
  if (!t) return;
  t.textContent = (color === 'green' ? '✓ ' : '⚠ ') + msg;
  t.style.background = color === 'green' ? '#22c55e' : '#ef4444';
  t.style.display = '';
  t.style.opacity = '1';
  setTimeout(() => { t.style.opacity = '0'; setTimeout(() => { t.style.display = 'none'; t.style.opacity = '1'; }, 400); }, 3500);
}

async function doApply() {
  if (!pendingInternId) return;
  const errEl = document.getElementById('ma-form-err');

  const name   = (document.getElementById('maf-name').value  || '').trim();
  const email  = (document.getElementById('maf-email').value || '').trim();
  const phone  = (document.getElementById('maf-phone').value || '').trim();
  const salary = (document.getElementById('maf-salary')?.value || '').trim();
  const reason = (document.getElementById('maf-reason').value|| '').trim();

  // Collect selected projects & certs
  const projChecks = document.querySelectorAll('.ma-proj-chk:checked');
  const certChecks = document.querySelectorAll('.ma-cert-chk:checked');
  const projectIds = Array.from(projChecks).map(c => c.value).join(',');
  const certIds    = Array.from(certChecks).map(c => c.value).join(',');

  // Validate
  if (!name || !email || !phone) {
    errEl.textContent = 'Please fill in your name, email and phone.';
    errEl.style.display = 'block'; return;
  }
  if (!salary || isNaN(salary) || Number(salary) <= 0) {
    errEl.textContent = 'Please enter your expected salary (PKR/month).';
    errEl.style.display = 'block'; return;
  }
  if (!reason) {
    errEl.textContent = 'Please write your cover letter / motivation.';
    errEl.style.display = 'block'; return;
  }
  if (!projectIds) {
    errEl.textContent = 'Please select at least one project to showcase.';
    errEl.style.display = 'block'; return;
  }
  if (!certIds) {
    errEl.textContent = 'Please select at least one certificate.';
    errEl.style.display = 'block'; return;
  }

  errEl.style.display = 'none';

  let res;
  try {
    res = await api('apply', {
      internship_id: pendingInternId,
      cover_letter:  reason,
      phone:         phone,
      expected_salary: salary,
      selected_project_ids: projectIds,
      selected_cert_ids:    certIds
    });
  } catch(e) {
    errEl.textContent = 'Network error. Please try again.';
    errEl.style.display = 'block'; return;
  }

  if (res && res.success) {
    closeM('m-apply');
    showToast('Your application has been submitted!', 'green');
    try {
      const refresh = await api('get_applications');
      if (refresh.success) applications = refresh.applications;
    } catch(e) {}
    sPg('s-applied', 'sn-applied');
    loadStats();
    api('get_recent_activity').then(r => { if(r && r.success){ recentActivity = r.activity || []; renderRecentActivity(); } }).catch(()=>{});
    renderNotifInternships();
  } else {
    errEl.textContent = (res && res.error) ? res.error : 'Submission failed. Please try again.';
    errEl.style.display = 'block';
  }
}

async function loadStats() {
  const st = await api('get_stats');
  document.getElementById('h-skills-ct').textContent = st.stats?.skills ?? 0;
  document.getElementById('h-cert-ct').textContent = st.stats?.certs ?? 0;
  document.getElementById('h-app-ct').textContent = st.stats?.applications ?? 0;
  document.getElementById('h-best-score').textContent = st.stats?.best_score ?? '—';
}

// ===================== NOTIFICATIONS INTERNSHIP SEARCH =====================
function renderNotifInternships(highlightId = null) {
  const el = document.getElementById('notif-intern-list');
  if (!el) return;
  const q   = (document.getElementById('n-search')?.value || '').toLowerCase();
  const dom = document.getElementById('n-filter')?.value || '';
  const list = internships.filter(i =>
    (!q   || i.title.toLowerCase().includes(q) || i.domain.toLowerCase().includes(q) || (i.company_name||'').toLowerCase().includes(q)) &&
    (!dom || i.domain === dom)
  );
  if (!list.length) {
    el.innerHTML = '<p class="text-muted center" style="padding:2rem;">No internships found. Try a different search.</p>';
    return;
  }
  const colorMap = { quiz_pass: 'green', quiz_fail: 'red' };
  el.innerHTML = list.map(i => {
    const score   = quizScores[i.domain] || 0;
    const qual    = score >= 80;
    const applied = applications.some(a => a.internship_id == i.id);
    const skills  = (i.skills || '').split(',').filter(Boolean).map(s => `<span class="tag gray">${escHtml(s.trim())}</span>`).join(' ');
    let actionHtml = '';
    if (applied) {
      actionHtml = '<span class="tag green">&#10003; Applied</span>';
    } else if (qual) {
      actionHtml = `<button class="btn sm blue" onclick="openApply(${i.id})">Apply Now</button><span class="tag green">Quiz passed &#10003;</span>`;
    } else {
      const attempted = quizScores[i.domain] !== undefined;
      actionHtml = `<button class="btn sm amber" onclick="openApply(${i.id})">Apply (Quiz Required)</button>`
        + (attempted ? `<span class="tag red">Score: ${score}% &mdash; need 80%</span>` : `<span class="tag amber">No quiz taken yet</span>`);
    }
    const isHighlighted = highlightId && i.id == highlightId;
    const highlightStyle = isHighlighted
      ? 'border:2.5px solid var(--blue);box-shadow:0 0 0 4px var(--blue-lt);'
      : '';
    const highlightBadge = isHighlighted
      ? `<span class="tag blue" style="font-size:11px;margin-bottom:6px;">&#128279; From your notification</span><br>`
      : '';
    return `<div class="intern-card" id="icard-${i.id}" style="${highlightStyle}">
      ${highlightBadge}
      <div class="ic-company">${escHtml(i.company_name || '')}</div>
      <div class="ic-title">${escHtml(i.title)}</div>
      <div class="ic-meta">
        <span>&#128197; ${escHtml(i.duration)}</span>
        <span>&#128188; ${escHtml(i.domain)}</span>
        <span class="ic-stipend">PKR ${parseInt(i.stipend).toLocaleString()}/month</span>
        <span>&#128101; ${i.applicant_count || 0} applied</span>
      </div>
      <div class="ic-desc">${escHtml(i.description || '')}</div>
      <div class="ic-skills">${skills}</div>
      <div class="ic-actions">${actionHtml}</div>
    </div>`;
  }).join('');

  // Scroll to highlighted card
  if (highlightId) {
    setTimeout(() => {
      const card = document.getElementById('icard-' + highlightId);
      if (card) card.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 100);
  }
}

// ===================== RECENT ACTIVITY =====================
function renderRecentActivity() {
  const el = document.getElementById('recent-activity-list');
  if (!el) return;
  if (!recentActivity.length) {
    el.innerHTML = '<div class="notif-row"><div class="text-muted">No recent activity yet. Take a quiz or apply for an internship!</div></div>';
    return;
  }
  const iconMap = {
    quiz_pass: { icon: '&#10003;', bg: 'var(--green-lt)' },
    quiz_fail: { icon: '&#10007;', bg: 'var(--red-lt, #ffeaea)' },
    application: { icon: '&#128203;', bg: 'var(--blue-lt)' }
  };
  el.innerHTML = recentActivity.map(a => {
    const m = iconMap[a.type] || { icon: '&#9679;', bg: 'var(--border)' };
    const dt = new Date(a.time).toLocaleString();
    // For quiz activities, show a direct "Attempt Quiz" button
    let quizBtn = '';
    if ((a.type === 'quiz_pass' || a.type === 'quiz_fail') && a.domain) {
      quizBtn = `<div style="margin-top:6px;"><button class="btn sm blue" onclick="startQuiz('${a.domain}')">&#9654; Attempt ${a.domain} Quiz</button></div>`;
    } else if (a.type === 'new_post' && a.domain && quizScores[a.domain] === undefined) {
      // New internship post aur quiz attempt nahi hua — direct quiz start karo
      quizBtn = `<div style="margin-top:6px;"><button class="btn sm blue" onclick="startQuiz('${a.domain}')">&#128221; Take ${a.domain} Quiz</button></div>`;
    }
    return `<div class="notif-row" style="align-items:flex-start;">
      <div class="ni-icon" style="background:${m.bg};margin-top:2px;">${m.icon}</div>
      <div style="flex:1;"><div class="fw-500">${escHtml(a.title)}</div><div class="text-sm text-muted mt-4">${escHtml(a.sub)} &middot; ${dt}</div>${quizBtn}</div>
    </div>`;
  }).join('');
}

// ===================== NOTIFICATIONS =====================
function formatNotifDate(dateStr) {
  const d   = new Date(dateStr);
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const yesterday = new Date(today); yesterday.setDate(today.getDate() - 1);
  const dDay = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  if (dDay.getTime() === today.getTime())     return 'Today';
  if (dDay.getTime() === yesterday.getTime()) return 'Yesterday';
  return d.toLocaleDateString('en-PK', { day:'numeric', month:'short', year:'numeric' });
}

function renderNotifications() {
  const el = document.getElementById('notif-card');
  if (!el) return;

  // Search filter
  const searchInput = document.getElementById('notif-search');
  const q = searchInput ? searchInput.value.trim().toLowerCase() : '';

  // Build search box HTML once
  const searchBox = `<div style="padding:14px 16px 0;">
    <div style="display:flex;gap:8px;margin-bottom:12px;">
      <input id="notif-search" value="${q}" placeholder="search new post....."
        oninput="renderNotifications()"
        style="flex:1;padding:8px 12px;border:1.5px solid var(--border);border-radius:9px;font-size:13px;background:var(--bg);color:var(--text);" />
      <button class="btn sm blue" onclick="renderNotifications()" style="padding:8px 14px;">&#128269;</button>
    </div>
  </div>`;

  if (!notifications.length) {
    el.innerHTML = searchBox + '<div class="notif-row"><div class="text-muted" style="padding:1rem;">No notifications yet.</div></div>';
    return;
  }

  const iconMap = {
    new_post:   { icon: '&#128227;', bg: 'var(--amber-lt)' },
    app_status: { icon: '&#128203;', bg: 'var(--blue-lt)' },
    quiz_pass:  { icon: '&#10003;',  bg: 'var(--green-lt)' }
  };

  // Filter by search
  let filtered = notifications;
  if (q) {
    filtered = notifications.filter(n => {
      const label = formatNotifDate(n.time).toLowerCase();
      const timeStr = new Date(n.time).toLocaleDateString('en-PK', { day:'numeric', month:'long', year:'numeric' }).toLowerCase();
      return n.title.toLowerCase().includes(q) ||
             n.sub.toLowerCase().includes(q) ||
             label.includes(q) ||
             timeStr.includes(q);
    });
  }

  if (!filtered.length) {
    el.innerHTML = searchBox + '<div class="notif-row"><div class="text-muted" style="padding:1rem;">No notifications match your search.</div></div>';
    // Re-attach input value
    setTimeout(() => { const inp = document.getElementById('notif-search'); if(inp){ inp.value = q; inp.focus(); inp.setSelectionRange(inp.value.length, inp.value.length); } }, 0);
    return;
  }

  // Group by date label
  const groups = {};
  filtered.forEach(n => {
    const label = formatNotifDate(n.time);
    if (!groups[label]) groups[label] = [];
    groups[label].push(n);
  });

  // Sort group keys: Today first, Yesterday second, then by date desc
  const sortedKeys = Object.keys(groups).sort((a, b) => {
    if (a === 'Today') return -1; if (b === 'Today') return 1;
    if (a === 'Yesterday') return -1; if (b === 'Yesterday') return 1;
    return new Date(b) - new Date(a);
  });

  let html = searchBox;
  sortedKeys.forEach(label => {
    html += `<div style="padding:10px 16px 4px;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:0.8px;color:var(--muted);">${label}</div>`;
    groups[label].forEach(n => {
      const m   = iconMap[n.type] || { icon: '&#9679;', bg: 'var(--border)' };
      const tm  = new Date(n.time).toLocaleTimeString('en-PK', { hour:'2-digit', minute:'2-digit' });
      // "View Post" button only for new_post type
      let viewBtn = '';
      if (n.type === 'new_post' && n.internship_id) {
        viewBtn = `<button class="btn sm blue" style="margin-top:6px;font-size:11px;padding:4px 10px;"
             onclick="goToInternshipPost(${n.internship_id})">&#128279; View Post</button>`;
        // Agar is domain ka quiz attempt nahi hua to direct startQuiz button bhi dikhao
        if (n.domain && quizScores[n.domain] === undefined) {
          viewBtn += ` <button class="btn sm" style="margin-top:6px;font-size:11px;padding:4px 10px;"
             onclick="startQuiz('${n.domain}')">&#128221; Take ${n.domain} Quiz</button>`;
        }
      }
      html += `<div class="notif-row" style="align-items:flex-start;">
        <div class="ni-icon" style="background:${m.bg};margin-top:2px;">${m.icon}</div>
        <div style="flex:1;">
          <div class="fw-500">${escHtml(n.title)}</div>
          <div class="text-sm text-muted mt-4">${escHtml(n.sub)} &middot; ${tm}</div>
          ${viewBtn}
        </div>
      </div>`;
    });
  });

  el.innerHTML = html;

  // Re-attach input value and cursor
  setTimeout(() => {
    const inp = document.getElementById('notif-search');
    if (inp && q) { inp.value = q; inp.focus(); inp.setSelectionRange(inp.value.length, inp.value.length); }
  }, 0);

  // Update badge
  const badge = document.getElementById('notif-badge');
  if (badge) badge.style.display = notifications.length ? '' : 'none';
}

// Navigate to internship post and highlight it
function goToInternshipPost(internId) {
  sPg('s-intern', 'sn-intern');
  // Clear search so the post is visible
  const ns = document.getElementById('n-search');
  const nf = document.getElementById('n-filter');
  if (ns) ns.value = '';
  if (nf) nf.value = '';
  renderNotifInternships(internId);
}

// ===================== QUIZ =====================
const QUIZ_BANK = {
  Python: [
    { q: "What is the output of: print(type([]))?", opts: ["<class 'list'>", "<class 'array'>", "<class 'tuple'>", "Error"], a: 0 },
    { q: "Which keyword is used to define a function in Python?", opts: ["function", "def", "func", "define"], a: 1 },
    { q: "What does len([1, 2, 3]) return?", opts: ["2", "3", "4", "Error"], a: 1 },
    { q: "Which of these is a valid Python dictionary?", opts: ["{1,2,3}", "[1:2,3:4]", "{'a':1,'b':2}", "(a=1,b=2)"], a: 2 },
    { q: "How do you start a comment in Python?", opts: ["//", "/*", "#", "--"], a: 2 },
    { q: "What does 'self' refer to in a Python class method?", opts: ["A keyword", "The current object instance", "A built-in function", "A module"], a: 1 },
    { q: "What does range(5) produce?", opts: ["[1,2,3,4,5]", "[0,1,2,3,4]", "[0,1,2,3,4,5]", "[1,2,3,4]"], a: 1 },
    { q: "Which list method removes and returns the last item?", opts: ["remove()", "delete()", "pop()", "drop()"], a: 2 },
    { q: "What does the 'import' keyword do in Python?", opts: ["Defines a function", "Loads a module", "Creates a class", "Exports code"], a: 1 },
    { q: "What is the result of: 10 // 3?", opts: ["3.33", "3", "4", "Error"], a: 1 },
  ],
  PHP: [
    { q: "How do you declare a variable in PHP?", opts: ["var x", "let x", "$x", "x ="], a: 2 },
    { q: "Which function outputs text in PHP?", opts: ["console.log()", "echo or print", "System.out.println()", "printf() only"], a: 1 },
    { q: "What is the correct way to end a PHP statement?", opts: [":", ".", ";", "end"], a: 2 },
    { q: "How do you open a PHP block?", opts: ["<php>", "<?php", "<script php>", "[php]"], a: 1 },
    { q: "Which superglobal holds HTTP POST data?", opts: ["$_GET", "$_POST", "$_FORM", "$_DATA"], a: 1 },
    { q: "Which function connects to MySQL in modern PHP?", opts: ["mysql_connect()", "mysqli_connect()", "connect_mysql()", "db_connect()"], a: 1 },
    { q: "What does '==' compare vs '==='?", opts: ["Same thing", "== compares value only, === compares value and type", "=== is for objects", "None of the above"], a: 1 },
    { q: "Which function returns the number of array elements?", opts: ["length()", "size()", "count()", "len()"], a: 2 },
    { q: "How do you create an array in PHP?", opts: ["array(1,2,3) or [1,2,3]", "list(1,2,3)", "new Array(1,2,3)", "arr(1,2,3)"], a: 0 },
    { q: "Which PHP tag is used to embed PHP in HTML?", opts: ["<php>...</php>", "<?php ... ?>", "<? ... ?>", "<script type=php>"], a: 1 },
  ],
  Java: [
    { q: "What is the entry-point method in a Java application?", opts: ["start()", "main()", "run()", "init()"], a: 1 },
    { q: "Which keyword instantiates an object in Java?", opts: ["create", "make", "new", "object"], a: 2 },
    { q: "What does System.out.println() do?", opts: ["Reads input", "Prints a line to stdout", "Exits the program", "Imports a class"], a: 1 },
    { q: "What is a Java interface?", opts: ["A class with implementation", "A contract of abstract methods", "A data type", "A variable"], a: 1 },
    { q: "Which access modifier makes a member accessible everywhere?", opts: ["private", "protected", "public", "default"], a: 2 },
    { q: "What is inheritance in Java?", opts: ["Copying code", "A class acquiring properties of another", "Method overloading", "Data hiding"], a: 1 },
    { q: "What is the size of an int in Java?", opts: ["2 bytes", "4 bytes", "8 bytes", "Platform-dependent"], a: 1 },
    { q: "What does the 'final' keyword do when applied to a variable?", opts: ["Makes it static", "Prevents its value from being changed", "Deletes it", "Makes it global"], a: 1 },
    { q: "Which exception is thrown on null reference access?", opts: ["NullException", "NullPointerException", "IllegalArgumentException", "RuntimeException"], a: 1 },
    { q: "Which Java collection maintains insertion order and allows duplicates?", opts: ["HashSet", "TreeSet", "ArrayList", "HashMap"], a: 2 },
  ],
  DBS: [
    { q: "What does SQL stand for?", opts: ["Structured Query Language", "Simple Query Logic", "Sequenced Query Lines", "Standard Queue Language"], a: 0 },
    { q: "Which SQL command retrieves data from a table?", opts: ["INSERT", "UPDATE", "SELECT", "FETCH"], a: 2 },
    { q: "What is a PRIMARY KEY?", opts: ["A foreign key", "A unique identifier for each row", "An index", "A check constraint"], a: 1 },
    { q: "What does JOIN do in SQL?", opts: ["Deletes rows", "Combines rows from multiple tables", "Creates a new table", "Sorts results"], a: 1 },
    { q: "Which command removes all rows without deleting the table structure?", opts: ["DROP", "DELETE", "TRUNCATE", "REMOVE"], a: 2 },
    { q: "What is database normalization?", opts: ["Adding more columns", "Organising data to reduce redundancy", "Backing up the database", "Encrypting data"], a: 1 },
    { q: "What does NULL represent in a database?", opts: ["Zero", "Empty string", "Unknown or missing value", "False"], a: 2 },
    { q: "Which SQL keyword filters results after GROUP BY?", opts: ["WHERE", "HAVING", "FILTER", "AFTER"], a: 1 },
    { q: "What is the primary purpose of a database index?", opts: ["Store images", "Speed up query execution", "Join tables", "Encrypt data"], a: 1 },
    { q: "What is a FOREIGN KEY?", opts: ["The primary key of the same table", "A key referencing another table's primary key", "An auto-increment column", "A composite key"], a: 1 },
  ]
};

let qz = { lang: '', questions: [], idx: 0, chosen: null, correct: 0 };

function updateQStatus() {
  ['Python', 'PHP', 'Java', 'DBS'].forEach(lang => {
    const el = document.getElementById('qs-' + lang);
    if (!el) return;
    const sc = quizScores[lang];
    if (sc !== undefined) {
      el.innerHTML = sc >= 80 ? `<span class="tag green">Passed: ${sc}%</span>` : `<span class="tag red">Failed: ${sc}% &mdash; retry</span>`;
    } else {
      el.innerHTML = `<span class="tag gray">Not attempted</span>`;
    }
  });
}

function startQuiz(lang) {
  qz = { lang, questions: [...QUIZ_BANK[lang]], idx: 0, chosen: null, correct: 0 };
  document.getElementById('qz-lang').textContent = lang + ' Quiz';
  sPg('s-quiz-active', 'sn-quiz');
  renderQ();
}

function renderQ() {
  const q = qz.questions[qz.idx];
  const total = qz.questions.length;
  document.getElementById('qz-prog-txt').textContent = `Q ${qz.idx + 1} of ${total}`;
  document.getElementById('qz-fill').style.width = ((qz.idx + 1) / total * 100) + '%';
  document.getElementById('qz-q').textContent = q.q;
  function escHtml(s){ return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
  document.getElementById('qz-opts').innerHTML = q.opts.map((opt, i) =>
    `<div class="opt" id="opt${i}" onclick="pickOpt(${i})"><div class="opt-dot" id="dot${i}"></div>${escHtml(opt)}</div>`
  ).join('');
  const nb = document.getElementById('qz-next');
  nb.disabled = true;
  nb.textContent = qz.idx === qz.questions.length - 1 ? 'See Result' : 'Next \u2192';
  qz.chosen = null;
}

function pickOpt(idx) {
  if (qz.chosen !== null) return;
  qz.chosen = idx;
  const q = qz.questions[qz.idx];
  document.querySelectorAll('.opt').forEach((el, i) => {
    if (i === q.a) el.classList.add('ok');
    else if (i === idx) el.classList.add('bad');
  });
  if (idx === q.a) qz.correct++;
  document.getElementById('qz-next').disabled = false;
}

function nextQ() {
  if (qz.chosen === null) return;
  if (qz.idx < qz.questions.length - 1) { qz.idx++; renderQ(); }
  else showQResult();
}

async function showQResult() {
  const score = Math.round((qz.correct / qz.questions.length) * 100);
  quizScores[qz.lang] = score;
  await api('submit_quiz', { domain: qz.lang, score });
  const pass = score >= 80;
  const ring = document.getElementById('qz-ring');
  ring.className = 'score-ring ' + (pass ? 'pass' : 'fail');
  document.getElementById('qz-pct').textContent = score + '%';
  document.getElementById('qz-frac').textContent = `${qz.correct} / ${qz.questions.length} correct`;
  document.getElementById('qz-rtitle').textContent = pass ? '\uD83C\udf89 Congratulations \u2014 you passed!' : '\uD83D\uDCDA Keep practising!';
  document.getElementById('qz-rmsg').textContent = pass
    ? `Excellent work! You scored ${score}% on the ${qz.lang} quiz. You're now eligible to apply for ${qz.lang} internships.`
    : `You scored ${score}% on the ${qz.lang} quiz. You need at least 80% to qualify. Review your skills and try again \u2014 you've got this!`;

  // Update result page buttons based on pass/fail
  const resultBtns = document.getElementById('qz-result-btns');
  if (resultBtns) {
    if (pass) {
      resultBtns.innerHTML = `
        <button class="btn blue" onclick="sPg('s-intern','sn-intern')">Browse Internships</button>
        <button class="btn" onclick="startQuiz('${qz.lang}')">Take Another Quiz</button>`;
    } else {
      resultBtns.innerHTML = `
        <button class="btn blue" onclick="startQuiz('${qz.lang}')">&#9654; Try Again</button>`;
    }
  }

  sPg('s-quiz-result', 'sn-quiz');
  loadStats();
  // Refresh recent activity after quiz
  api('get_recent_activity').then(r => { if(r.success){ recentActivity = r.activity; renderRecentActivity(); } });
  api('get_notifications').then(r => { if(r.success){ notifications = r.notifications; } });
}

// ===================== MODALS =====================
function openM(id) { document.getElementById(id).classList.add('open'); }
function closeM(id) { document.getElementById(id).classList.remove('open'); }
document.querySelectorAll('.overlay').forEach(o => {
  o.addEventListener('click', e => { if (e.target === o) o.classList.remove('open'); });
});
