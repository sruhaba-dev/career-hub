<?php
// Career Hub - Database Connection
// Update these credentials to match your MySQL setup

$host = 'localhost';
$db   = 'career_hub';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

// -----------------------------------------------------------------------
// Make sure this endpoint ALWAYS returns valid JSON, even if something
// goes wrong (missing table, PHP notice, wrong DB credentials, etc).
// Without this, PHP would print raw HTML/warning text before our JSON,
// the browser's fetch().json() call would fail to parse it, and the
// front-end would show a generic "Network error" instead of the real
// reason. This block turns any uncaught error/exception into a proper
// JSON error response instead.
// -----------------------------------------------------------------------
ini_set('display_errors', '0');
error_reporting(E_ALL);

// Allow the API to be called from a front-end served on a different
// origin/port (common when testing with Live Server, XAMPP + a separate
// dev server, etc). Also required for the browser to send/receive the
// PHP session cookie that keeps the user logged in.
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($origin !== '') {
    header("Access-Control-Allow-Origin: $origin");
    header('Access-Control-Allow-Credentials: true');
}
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Preflight request - answer it immediately, nothing else to do.
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

header('Content-Type: application/json');

function jsonResponse($data) {
    echo json_encode($data);
    exit;
}

function jsonFatal($message, $code = 500) {
    if (!headers_sent()) {
        http_response_code($code);
        header('Content-Type: application/json');
    }
    echo json_encode(['success' => false, 'error' => $message]);
    exit;
}

// Catch any PHP error (undefined variable, missing extension, etc.) and
// turn it into a JSON response instead of letting it print raw HTML.
set_error_handler(function ($severity, $message, $file, $line) {
    if (!(error_reporting() & $severity)) {
        return false;
    }
    jsonFatal('Server error: ' . $message);
});

// Catch any uncaught exception (including PDOException from a bad query)
// and turn it into a JSON response instead of a fatal error page.
set_exception_handler(function ($e) {
    jsonFatal('Server error: ' . $e->getMessage());
});

// Session cookie settings - SameSite=Lax works for same-site setups; if
// the front-end and API end up on different domains over HTTPS, change
// 'samesite' to 'None' and 'secure' to true.
// SameSite=None + Secure is required when the front-end and PHP backend
// are on different origins (e.g. VS Code Live Server on :5500 + XAMPP on :80).
// SameSite=None only works over HTTPS; on plain HTTP the browser ignores it
// and blocks the cookie. THE SIMPLEST FIX: put your HTML files inside
// XAMPP's htdocs/career-hub/ folder and open them via http://localhost/career-hub/
// (same origin as the PHP files) — then SameSite=Lax works fine.
// If you must use separate servers over HTTPS, change 'samesite' to 'None'.
$isHttps = (($_SERVER['HTTPS'] ?? '') === 'on');
session_set_cookie_params([
    'lifetime' => 0,
    'path'     => '/',
    'secure'   => $isHttps,
    'httponly' => true,
    'samesite' => $isHttps ? 'None' : 'Lax',
]);
session_start();

// -----------------------------------------------------------------------
// Basic CSRF protection (double-submit cookie pattern).
// A random token is stored in the session and mirrored into a readable
// (non-HttpOnly) cookie. The front-end JS reads the cookie and sends the
// same value back as `csrf_token` on state-changing requests. Since a
// third-party site cannot read our cookie (browsers block cross-site
// cookie reads), it cannot forge a matching token, even though the
// session cookie itself is sent automatically by the browser.
// -----------------------------------------------------------------------
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
setcookie('ch_csrf', $_SESSION['csrf_token'], [
    'expires'  => 0,
    'path'     => '/',
    'secure'   => $isHttps,
    'httponly' => false, // must be readable by front-end JS
    'samesite' => $isHttps ? 'None' : 'Lax',
]);

// Call this at the top of any action that creates/updates/deletes data.
function requireCsrf() {
    $token = $_POST['csrf_token'] ?? '';
    if (empty($token) || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        jsonResponse(['success' => false, 'error' => 'Your session security token is invalid or expired. Please refresh the page and try again.']);
    }
}

// Basic http/https URL validator used across profile/project/cert fields.
// Returns true for an empty string (field is optional almost everywhere).
function isValidUrlOrEmpty($url) {
    $url = trim((string)$url);
    if ($url === '') return true;
    if (!filter_var($url, FILTER_VALIDATE_URL)) return false;
    $scheme = strtolower((string) parse_url($url, PHP_URL_SCHEME));
    return in_array($scheme, ['http', 'https'], true);
}

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=$charset", $user, $pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
} catch (PDOException $e) {
    jsonFatal('Database connection failed: ' . $e->getMessage());
}

function requireAuth($type) {
    if ($type === 'student' && empty($_SESSION['student_id'])) {
        jsonResponse(['success' => false, 'error' => 'Unauthorized']);
    }
    if ($type === 'employer' && empty($_SESSION['employer_id'])) {
        jsonResponse(['success' => false, 'error' => 'Unauthorized']);
    }
}
