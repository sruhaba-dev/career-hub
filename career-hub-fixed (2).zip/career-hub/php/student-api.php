<?php
require 'db.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';

// All student actions require authentication
if (!in_array($action, [])) {
    requireAuth('student');
}

$studentId = $_SESSION['student_id'] ?? 0;

// Actions that create/update/delete data must carry a valid CSRF token.
// Read-only "get_*" actions are safe and don't need it.
$mutatingActions = ['update_profile', 'add_skill', 'delete_skill', 'add_cert', 'delete_cert',
    'add_project', 'delete_project', 'submit_quiz', 'apply'];
if (in_array($action, $mutatingActions, true)) {
    requireCsrf();
}

switch ($action) {

    // ===================== PROFILE =====================
    case 'get_profile':
        $stmt = $pdo->prepare("SELECT id, full_name, email, initials, age, location, resume_url, profile_pic FROM students WHERE id = ?");
        $stmt->execute([$studentId]);
        $profile = $stmt->fetch();
        jsonResponse(['success' => true, 'profile' => $profile]);

    case 'update_profile':
        $name   = trim($_POST['full_name'] ?? '');
        $email  = trim($_POST['email'] ?? '');
        $ageRaw = trim($_POST['age'] ?? '');
        $loc    = trim($_POST['location'] ?? '');
        $resume = trim($_POST['resume_url'] ?? '');
        $pic    = trim($_POST['profile_pic'] ?? '');

        if (!$name) {
            jsonResponse(['success' => false, 'error' => 'Full name is required.']);
        }
        if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            jsonResponse(['success' => false, 'error' => 'Please enter a valid email address.']);
        }
        $age = null;
        if ($ageRaw !== '') {
            if (!ctype_digit($ageRaw) || (int)$ageRaw < 10 || (int)$ageRaw > 100) {
                jsonResponse(['success' => false, 'error' => 'Please enter a valid age between 10 and 100.']);
            }
            $age = (int)$ageRaw;
        }
        if (!isValidUrlOrEmpty($resume)) {
            jsonResponse(['success' => false, 'error' => 'Resume URL must be a valid http(s) link.']);
        }
        if (!isValidUrlOrEmpty($pic)) {
            jsonResponse(['success' => false, 'error' => 'Profile picture URL must be a valid http(s) link.']);
        }

        // Duplicate email check (excluding this student's own row)
        $stmt = $pdo->prepare("SELECT id FROM students WHERE email = ? AND id != ?");
        $stmt->execute([$email, $studentId]);
        if ($stmt->fetch()) {
            jsonResponse(['success' => false, 'error' => 'That email address is already in use by another account.']);
        }

        $initials = implode('', array_map(fn($w) => strtoupper($w[0] ?? ''), explode(' ', $name)));
        $initials = substr($initials, 0, 2);

        $stmt = $pdo->prepare("UPDATE students SET full_name = ?, email = ?, age = ?, location = ?, resume_url = ?, profile_pic = ?, initials = ? WHERE id = ?");
        $stmt->execute([$name, $email, $age, $loc, $resume, $pic, $initials, $studentId]);
        jsonResponse(['success' => true, 'message' => 'Profile saved successfully!']);

    // ===================== SKILLS =====================
    case 'get_skills':
        $stmt = $pdo->prepare("SELECT * FROM skills WHERE student_id = ? ORDER BY created_at DESC");
        $stmt->execute([$studentId]);
        jsonResponse(['success' => true, 'skills' => $stmt->fetchAll()]);

    case 'add_skill':
        $name = trim($_POST['name'] ?? '');
        $cat  = trim($_POST['category'] ?? 'Other');
        if (!$name) jsonResponse(['success' => false, 'error' => 'Skill name required']);
        $stmt = $pdo->prepare("INSERT INTO skills (student_id, name, category) VALUES (?, ?, ?)");
        $stmt->execute([$studentId, $name, $cat]);
        jsonResponse(['success' => true]);

    case 'delete_skill':
        $id = intval($_POST['id'] ?? 0);
        $stmt = $pdo->prepare("DELETE FROM skills WHERE id = ? AND student_id = ?");
        $stmt->execute([$id, $studentId]);
        jsonResponse(['success' => true]);

    // ===================== CERTIFICATIONS =====================
    case 'get_certs':
        $stmt = $pdo->prepare("SELECT * FROM certifications WHERE student_id = ? ORDER BY created_at DESC");
        $stmt->execute([$studentId]);
        jsonResponse(['success' => true, 'certs' => $stmt->fetchAll()]);

    case 'add_cert':
        $title = trim($_POST['title'] ?? '');
        $issuer = trim($_POST['issuer'] ?? '');
        $date  = $_POST['issue_date'] ?? null;
        $url   = trim($_POST['cert_url'] ?? '');
        if (!$title || !$issuer) jsonResponse(['success' => false, 'error' => 'Title and issuer required']);
        if (!isValidUrlOrEmpty($url)) jsonResponse(['success' => false, 'error' => 'Certificate URL must be a valid http(s) link.']);
        $stmt = $pdo->prepare("INSERT INTO certifications (student_id, title, issuer, issue_date, cert_url) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$studentId, $title, $issuer, $date ?: null, $url]);
        jsonResponse(['success' => true]);

    case 'delete_cert':
        $id = intval($_POST['id'] ?? 0);
        $stmt = $pdo->prepare("DELETE FROM certifications WHERE id = ? AND student_id = ?");
        $stmt->execute([$id, $studentId]);
        jsonResponse(['success' => true]);

    // ===================== PROJECTS =====================
    case 'get_projects':
        $stmt = $pdo->prepare("SELECT * FROM projects WHERE student_id = ? ORDER BY created_at DESC");
        $stmt->execute([$studentId]);
        jsonResponse(['success' => true, 'projects' => $stmt->fetchAll()]);

    case 'add_project':
        $title   = trim($_POST['title'] ?? '');
        $desc    = trim($_POST['description'] ?? '');
        $stack   = trim($_POST['tech_stack'] ?? '');
        $date    = $_POST['project_date'] ?? null;
        $projUrl = trim($_POST['project_url'] ?? '');
        if (!$title) jsonResponse(['success' => false, 'error' => 'Project title required']);
        if (!isValidUrlOrEmpty($projUrl)) jsonResponse(['success' => false, 'error' => 'Project URL must be a valid http(s) link (e.g. https://github.com/...).']);
        $stmt = $pdo->prepare("INSERT INTO projects (student_id, title, description, tech_stack, project_url, project_date) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$studentId, $title, $desc, $stack, $projUrl ?: null, $date ?: null]);
        jsonResponse(['success' => true]);

    case 'delete_project':
        $id = intval($_POST['id'] ?? 0);
        $stmt = $pdo->prepare("DELETE FROM projects WHERE id = ? AND student_id = ?");
        $stmt->execute([$id, $studentId]);
        jsonResponse(['success' => true]);

    // ===================== QUIZ SCORES =====================
    case 'get_quiz_scores':
        $stmt = $pdo->prepare("SELECT domain, score FROM quiz_scores WHERE student_id = ?");
        $stmt->execute([$studentId]);
        $scores = [];
        foreach ($stmt->fetchAll() as $row) {
            $scores[$row['domain']] = intval($row['score']);
        }
        jsonResponse(['success' => true, 'scores' => $scores]);

    case 'submit_quiz':
        $domain = trim($_POST['domain'] ?? '');
        $score  = intval($_POST['score'] ?? 0);
        if (!$domain) jsonResponse(['success' => false, 'error' => 'Domain required']);
        $stmt = $pdo->prepare("INSERT INTO quiz_scores (student_id, domain, score) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE score = GREATEST(score, VALUES(score)), taken_at = CURRENT_TIMESTAMP");
        $stmt->execute([$studentId, $domain, $score]);
        jsonResponse(['success' => true]);

    // ===================== INTERNSHIPS =====================
    case 'get_internships':
        $stmt = $pdo->query("
            SELECT i.*, e.company_name,
                (SELECT COUNT(*) FROM applications a WHERE a.internship_id = i.id) as applicant_count
            FROM internships i
            JOIN employers e ON i.employer_id = e.id
            ORDER BY i.created_at DESC
        ");
        jsonResponse(['success' => true, 'internships' => $stmt->fetchAll()]);

    // ===================== APPLICATIONS =====================
    case 'get_applications':
        $stmt = $pdo->prepare("SELECT a.id, a.student_id, a.internship_id, a.status, a.applied_at, i.title as intern_title, i.company_name, i.domain FROM applications a JOIN internships i ON a.internship_id = i.id WHERE a.student_id = ? ORDER BY a.applied_at DESC");
        $stmt->execute([$studentId]);
        jsonResponse(['success' => true, 'applications' => $stmt->fetchAll()]);

    case 'apply':
        $internshipId = intval($_POST['internship_id'] ?? 0);
        if (!$internshipId) jsonResponse(['success' => false, 'error' => 'Internship ID required']);

        // Internship must exist - also gives us the domain for the quiz check
        $stmt = $pdo->prepare("SELECT id, domain, title FROM internships WHERE id = ?");
        $stmt->execute([$internshipId]);
        $internship = $stmt->fetch();
        if (!$internship) {
            jsonResponse(['success' => false, 'error' => 'This internship no longer exists.']);
        }
        $domain = $internship['domain'];

        // Check if already applied
        $stmt = $pdo->prepare("SELECT id FROM applications WHERE student_id = ? AND internship_id = ?");
        $stmt->execute([$studentId, $internshipId]);
        if ($stmt->fetch()) {
            jsonResponse(['success' => false, 'error' => 'You have already applied for this internship.']);
        }

        // -------------------------------------------------------------
        // SECURITY / BUSINESS RULE: enforce the 80% quiz requirement on
        // the backend. The frontend also checks this for UX, but that
        // check alone can be bypassed (e.g. calling this endpoint
        // directly), so it must be re-verified here before any insert.
        // -------------------------------------------------------------
        $stmt = $pdo->prepare("SELECT score FROM quiz_scores WHERE student_id = ? AND domain = ?");
        $stmt->execute([$studentId, $domain]);
        $quizRow = $stmt->fetch();
        if (!$quizRow) {
            jsonResponse(['success' => false, 'error' => "Please pass the $domain quiz with a score of at least 80% before applying."]);
        }
        if ((int)$quizRow['score'] < 80) {
            jsonResponse(['success' => false, 'error' => "Please pass the $domain quiz with a score of at least 80% before applying. Your current score is {$quizRow['score']}%."]);
        }

        $coverLetter    = trim($_POST['cover_letter'] ?? '');
        $phone          = trim($_POST['phone'] ?? '');
        $expectedSalary = trim($_POST['expected_salary'] ?? '');
        $projectIdsRaw  = trim($_POST['selected_project_ids'] ?? '');
        $certIdsRaw     = trim($_POST['selected_cert_ids'] ?? '');

        // Validate required fields
        if (empty($phone)) {
            jsonResponse(['success' => false, 'error' => 'Phone number is required.']);
        }
        if (empty($coverLetter)) {
            jsonResponse(['success' => false, 'error' => 'Cover letter is required.']);
        }
        if ($expectedSalary === '' || !ctype_digit($expectedSalary) || (int)$expectedSalary <= 0) {
            jsonResponse(['success' => false, 'error' => 'Please enter a valid expected salary.']);
        }

        // Validate: at least one project and one certificate required.
        // Give a clear, specific message when the student simply hasn't
        // added any yet, rather than a generic "selection" error.
        $hasAnyProject = $pdo->prepare("SELECT COUNT(*) c FROM projects WHERE student_id = ?");
        $hasAnyProject->execute([$studentId]);
        if ($hasAnyProject->fetch()['c'] == 0) {
            jsonResponse(['success' => false, 'error' => 'You need to add at least one project to your profile before applying. Go to Projects and add one first.']);
        }
        $hasAnyCert = $pdo->prepare("SELECT COUNT(*) c FROM certifications WHERE student_id = ?");
        $hasAnyCert->execute([$studentId]);
        if ($hasAnyCert->fetch()['c'] == 0) {
            jsonResponse(['success' => false, 'error' => 'You need to add at least one certification to your profile before applying. Go to Certifications and add one first.']);
        }
        if (empty($projectIdsRaw)) {
            jsonResponse(['success' => false, 'error' => 'Please select at least one project to showcase.']);
        }
        if (empty($certIdsRaw)) {
            jsonResponse(['success' => false, 'error' => 'Please select at least one certificate to include.']);
        }

        // Parse and de-duplicate the submitted ID lists
        $projectIdsArr = array_values(array_unique(array_filter(array_map('intval', explode(',', $projectIdsRaw)))));
        $certIdsArr    = array_values(array_unique(array_filter(array_map('intval', explode(',', $certIdsRaw)))));
        if (empty($projectIdsArr)) {
            jsonResponse(['success' => false, 'error' => 'Please select at least one project to showcase.']);
        }
        if (empty($certIdsArr)) {
            jsonResponse(['success' => false, 'error' => 'Please select at least one certificate to include.']);
        }

        // SECURITY: verify every selected project/cert actually belongs
        // to this student before storing their IDs on the application.
        $placeholders = implode(',', array_fill(0, count($projectIdsArr), '?'));
        $stmt = $pdo->prepare("SELECT COUNT(*) c FROM projects WHERE id IN ($placeholders) AND student_id = ?");
        $stmt->execute([...$projectIdsArr, $studentId]);
        if ((int)$stmt->fetch()['c'] !== count($projectIdsArr)) {
            jsonResponse(['success' => false, 'error' => 'One or more selected projects are invalid.']);
        }

        $placeholders = implode(',', array_fill(0, count($certIdsArr), '?'));
        $stmt = $pdo->prepare("SELECT COUNT(*) c FROM certifications WHERE id IN ($placeholders) AND student_id = ?");
        $stmt->execute([...$certIdsArr, $studentId]);
        if ((int)$stmt->fetch()['c'] !== count($certIdsArr)) {
            jsonResponse(['success' => false, 'error' => 'One or more selected certificates are invalid.']);
        }

        $projectIds = implode(',', $projectIdsArr);
        $certIds    = implode(',', $certIdsArr);
        $expectedSalaryInt = (int)$expectedSalary;

        try {
            $stmt = $pdo->prepare("INSERT INTO applications (student_id, internship_id, cover_letter, phone, expected_salary, selected_project_ids, selected_cert_ids) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$studentId, $internshipId, $coverLetter, $phone, $expectedSalaryInt, $projectIds, $certIds]);
            jsonResponse(['success' => true]);
        } catch (PDOException $e) {
            // Unique key violation = duplicate application (race condition
            // between the check above and this insert)
            if ((int)$e->getCode() === 23000 || strpos($e->getMessage(), 'unique_application') !== false) {
                jsonResponse(['success' => false, 'error' => 'You have already applied for this internship.']);
            }
            jsonResponse(['success' => false, 'error' => 'Could not submit application. Please try again.']);
        }


    // ===================== RECENT ACTIVITY =====================
    case 'get_recent_activity':
        $activity = [];

        $stmt = $pdo->prepare("SELECT domain, score, taken_at FROM quiz_scores WHERE student_id = ? ORDER BY taken_at DESC LIMIT 5");
        $stmt->execute([$studentId]);
        foreach ($stmt->fetchAll() as $row) {
            $activity[] = [
                'type'   => $row['score'] >= 80 ? 'quiz_pass' : 'quiz_fail',
                'title'  => 'Quiz ' . ($row['score'] >= 80 ? 'passed' : 'attempted') . ' -- ' . $row['domain'],
                'sub'    => 'Score: ' . $row['score'] . '%',
                'time'   => $row['taken_at'],
                'domain' => $row['domain']
            ];
        }

        $stmt = $pdo->prepare("SELECT i.title, i.company_name, a.status, a.applied_at FROM applications a JOIN internships i ON a.internship_id = i.id WHERE a.student_id = ? ORDER BY a.applied_at DESC LIMIT 5");
        $stmt->execute([$studentId]);
        foreach ($stmt->fetchAll() as $row) {
            $activity[] = [
                'type'  => 'application',
                'title' => 'Application submitted -- ' . $row['title'],
                'sub'   => $row['company_name'] . ' · Status: ' . $row['status'],
                'time'  => $row['applied_at']
            ];
        }

        usort($activity, function($x, $y) { return strtotime($y['time']) - strtotime($x['time']); });
        jsonResponse(['success' => true, 'activity' => array_slice($activity, 0, 8)]);

    // ===================== NOTIFICATIONS =====================
    case 'get_notifications':
        $notifs = [];

        $stmt = $pdo->query("SELECT i.id, i.title, i.company_name, i.domain, i.created_at FROM internships i ORDER BY i.created_at DESC LIMIT 10");
        foreach ($stmt->fetchAll() as $row) {
            $notifs[] = [
                'type'         => 'new_post',
                'title'        => 'New internship posted -- ' . $row['title'],
                'sub'          => $row['company_name'] . ' · ' . $row['domain'],
                'time'         => $row['created_at'],
                'internship_id'=> (int)$row['id']
            ];
        }

        $stmt = $pdo->prepare("SELECT i.title, i.company_name, a.status, a.applied_at FROM applications a JOIN internships i ON a.internship_id = i.id WHERE a.student_id = ? AND a.status != 'Pending' ORDER BY a.applied_at DESC LIMIT 5");
        $stmt->execute([$studentId]);
        foreach ($stmt->fetchAll() as $row) {
            $notifs[] = [
                'type'          => 'app_status',
                'title'         => 'Application ' . strtolower($row['status']) . ' -- ' . $row['title'],
                'sub'           => $row['company_name'],
                'time'          => $row['applied_at'],
                'internship_id' => null
            ];
        }

        $stmt = $pdo->prepare("SELECT domain, score, taken_at FROM quiz_scores WHERE student_id = ? AND score >= 80 ORDER BY taken_at DESC LIMIT 5");
        $stmt->execute([$studentId]);
        foreach ($stmt->fetchAll() as $row) {
            $notifs[] = [
                'type'          => 'quiz_pass',
                'title'         => 'Quiz passed -- ' . $row['domain'],
                'sub'           => 'Score: ' . $row['score'] . '% · You are now eligible to apply',
                'time'          => $row['taken_at'],
                'internship_id' => null
            ];
        }

        usort($notifs, function($x, $y) { return strtotime($y['time']) - strtotime($x['time']); });
        jsonResponse(['success' => true, 'notifications' => array_slice($notifs, 0, 15)]);

    // ===================== DASHBOARD STATS =====================
    case 'get_stats':
        $skills = $pdo->prepare("SELECT COUNT(*) as c FROM skills WHERE student_id = ?");
        $skills->execute([$studentId]);
        $skillCount = $skills->fetch()['c'];

        $certs = $pdo->prepare("SELECT COUNT(*) as c FROM certifications WHERE student_id = ?");
        $certs->execute([$studentId]);
        $certCount = $certs->fetch()['c'];

        $apps = $pdo->prepare("SELECT COUNT(*) as c FROM applications WHERE student_id = ?");
        $apps->execute([$studentId]);
        $appCount = $apps->fetch()['c'];

        $stmt = $pdo->prepare("SELECT MAX(score) as best FROM quiz_scores WHERE student_id = ?");
        $stmt->execute([$studentId]);
        $best = $stmt->fetch()['best'];

        jsonResponse(['success' => true, 'stats' => [
            'skills' => $skillCount,
            'certs' => $certCount,
            'applications' => $appCount,
            'best_score' => $best ? $best . '%' : '—'
        ]]);

    default:
        jsonResponse(['success' => false, 'error' => 'Unknown action: ' . $action]);
}
