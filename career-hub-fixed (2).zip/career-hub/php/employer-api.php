<?php
require 'db.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';

// All employer actions require authentication
requireAuth('employer');

$employerId = $_SESSION['employer_id'] ?? 0;

// Actions that create/update/delete data must carry a valid CSRF token.
// Read-only "get_*" actions are safe and don't need it.
$mutatingActions = ['update_profile', 'add_posting', 'delete_posting', 'update_application_status'];
if (in_array($action, $mutatingActions, true)) {
    requireCsrf();
}

switch ($action) {

    // ===================== PROFILE =====================
    case 'get_profile':
        $stmt = $pdo->prepare("SELECT id, company_name, email, industry, website, description FROM employers WHERE id = ?");
        $stmt->execute([$employerId]);
        $profile = $stmt->fetch();
        jsonResponse(['success' => true, 'profile' => $profile]);

    case 'update_profile':
        $company = trim($_POST['company_name'] ?? '');
        $email   = trim($_POST['email'] ?? '');
        $industry = trim($_POST['industry'] ?? '');
        $website = trim($_POST['website'] ?? '');
        $desc    = trim($_POST['description'] ?? '');

        if (!$company) {
            jsonResponse(['success' => false, 'error' => 'Company name is required.']);
        }
        if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            jsonResponse(['success' => false, 'error' => 'Please enter a valid email address.']);
        }
        if (!isValidUrlOrEmpty($website)) {
            jsonResponse(['success' => false, 'error' => 'Website must be a valid http(s) link.']);
        }

        // Duplicate email check (excluding this employer's own row)
        $stmt = $pdo->prepare("SELECT id FROM employers WHERE email = ? AND id != ?");
        $stmt->execute([$email, $employerId]);
        if ($stmt->fetch()) {
            jsonResponse(['success' => false, 'error' => 'That email address is already in use by another account.']);
        }

        $stmt = $pdo->prepare("UPDATE employers SET company_name = ?, email = ?, industry = ?, website = ?, description = ? WHERE id = ?");
        $stmt->execute([$company, $email, $industry, $website, $desc, $employerId]);
        jsonResponse(['success' => true, 'message' => 'Profile saved successfully!']);

    // ===================== POSTINGS =====================
    case 'get_postings':
        $stmt = $pdo->prepare("
            SELECT i.*,
                (SELECT COUNT(*) FROM applications a WHERE a.internship_id = i.id) as applicant_count
            FROM internships i
            WHERE i.employer_id = ?
            ORDER BY i.created_at DESC
        ");
        $stmt->execute([$employerId]);
        jsonResponse(['success' => true, 'postings' => $stmt->fetchAll()]);

    case 'add_posting':
        $title    = trim($_POST['title'] ?? '');
        $domain   = trim($_POST['domain'] ?? '');
        $duration = trim($_POST['duration'] ?? '');
        $stipend  = intval($_POST['stipend'] ?? 0);
        $skills   = trim($_POST['skills'] ?? '');
        $desc     = trim($_POST['description'] ?? '');

        if (!$title || !$domain || !$duration || !$desc) {
            jsonResponse(['success' => false, 'error' => 'Please fill all required fields.']);
        }
        if ($stipend < 0) {
            jsonResponse(['success' => false, 'error' => 'Stipend cannot be negative.']);
        }

        $allowedDomains = ['Python', 'PHP', 'Java', 'DBS'];
        if (!in_array($domain, $allowedDomains)) {
            jsonResponse(['success' => false, 'error' => 'Please select a valid domain.']);
        }

        // Get company name from employer profile
        $stmt = $pdo->prepare("SELECT company_name FROM employers WHERE id = ?");
        $stmt->execute([$employerId]);
        $company = $stmt->fetch()['company_name'] ?? 'Your Company';

        $stmt = $pdo->prepare("INSERT INTO internships (employer_id, title, company_name, domain, duration, stipend, skills, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$employerId, $title, $company, $domain, $duration, $stipend, $skills, $desc]);
        jsonResponse(['success' => true]);

    case 'delete_posting':
        $id = intval($_POST['id'] ?? 0);
        $stmt = $pdo->prepare("DELETE FROM internships WHERE id = ? AND employer_id = ?");
        $stmt->execute([$id, $employerId]);
        jsonResponse(['success' => true]);

    // ===================== APPLICATIONS =====================
    case 'get_applications':
        $stmt = $pdo->prepare("
            SELECT a.id, a.student_id, a.internship_id, a.status, a.applied_at,
                   a.cover_letter, a.phone, a.selected_project_ids, a.selected_cert_ids,
                   s.full_name, s.email, s.initials, s.location, s.resume_url,
                   i.title as internship_title, i.domain,
                   qs.score as quiz_score
            FROM applications a
            JOIN students s ON a.student_id = s.id
            JOIN internships i ON a.internship_id = i.id
            LEFT JOIN quiz_scores qs ON qs.student_id = s.id AND qs.domain = i.domain
            WHERE i.employer_id = ?
            ORDER BY a.applied_at DESC
        ");
        $stmt->execute([$employerId]);
        jsonResponse(['success' => true, 'applications' => $stmt->fetchAll()]);

    case 'get_student_profile':
        $studentId = intval($_POST['student_id'] ?? 0);
        if (!$studentId) jsonResponse(['success' => false, 'error' => 'Student ID required']);

        // Verify this student has applied to one of this employer's internships
        $checkStmt = $pdo->prepare("
            SELECT COUNT(*) as cnt FROM applications a
            JOIN internships i ON a.internship_id = i.id
            WHERE a.student_id = ? AND i.employer_id = ?
        ");
        $checkStmt->execute([$studentId, $employerId]);
        if ($checkStmt->fetch()['cnt'] == 0) {
            jsonResponse(['success' => false, 'error' => 'Access denied']);
        }

        // Basic info
        $stmt = $pdo->prepare("SELECT id, full_name, email, location, resume_url FROM students WHERE id = ?");
        $stmt->execute([$studentId]);
        $student = $stmt->fetch();
        if (!$student) jsonResponse(['success' => false, 'error' => 'Student not found']);

        // Skills
        $stmt = $pdo->prepare("SELECT name, category FROM skills WHERE student_id = ? ORDER BY created_at DESC");
        $stmt->execute([$studentId]);
        $skills = $stmt->fetchAll();

        // Certifications
        $stmt = $pdo->prepare("SELECT id, title, issuer, issue_date, cert_url FROM certifications WHERE student_id = ? ORDER BY issue_date DESC");
        $stmt->execute([$studentId]);
        $certs = $stmt->fetchAll();

        // Projects (schema guarantees project_url exists - see database.sql)
        $stmt = $pdo->prepare("SELECT id, title, description, tech_stack, project_date, project_url FROM projects WHERE student_id = ? ORDER BY created_at DESC");
        $stmt->execute([$studentId]);
        $projects = $stmt->fetchAll();

        // All quiz scores
        $stmt = $pdo->prepare("SELECT domain, score FROM quiz_scores WHERE student_id = ? ORDER BY score DESC");
        $stmt->execute([$studentId]);
        $quizScores = $stmt->fetchAll();

        jsonResponse([
            'success'    => true,
            'student'    => $student,
            'skills'     => $skills,
            'certs'      => $certs,
            'projects'   => $projects,
            'quiz_scores'=> $quizScores
        ]);

    case 'update_application_status':
        $appId  = intval($_POST['application_id'] ?? 0);
        $status = trim($_POST['status'] ?? '');
        if (!$appId || !in_array($status, ['Pending', 'Accepted', 'Rejected'], true)) {
            jsonResponse(['success' => false, 'error' => 'Invalid request']);
        }
        // Ownership check: the application must belong to one of THIS
        // employer's internships. If it doesn't (wrong employer, or the
        // application ID doesn't exist), affectedRows will be 0.
        $stmt = $pdo->prepare("UPDATE applications SET status = ? WHERE id = ? AND internship_id IN (SELECT id FROM internships WHERE employer_id = ?)");
        $stmt->execute([$status, $appId, $employerId]);
        if ($stmt->rowCount() === 0) {
            // Distinguish "already in that status" (fine, idempotent) from
            // "doesn't belong to you / doesn't exist" (real error).
            $check = $pdo->prepare("SELECT a.status FROM applications a JOIN internships i ON a.internship_id = i.id WHERE a.id = ? AND i.employer_id = ?");
            $check->execute([$appId, $employerId]);
            $row = $check->fetch();
            if (!$row) {
                jsonResponse(['success' => false, 'error' => 'Application not found or you do not have permission to update it.']);
            }
            // Same status already set - treat as success (idempotent, safe on repeated clicks)
        }
        jsonResponse(['success' => true]);

    // ===================== DASHBOARD STATS =====================
    case 'get_stats':
        $postings = $pdo->prepare("SELECT COUNT(*) as c FROM internships WHERE employer_id = ?");
        $postings->execute([$employerId]);
        $postCount = $postings->fetch()['c'];

        $stmt = $pdo->prepare("
            SELECT COUNT(*) as c FROM applications a
            JOIN internships i ON a.internship_id = i.id
            WHERE i.employer_id = ?
        ");
        $stmt->execute([$employerId]);
        $appCount = $stmt->fetch()['c'];

        $stmt = $pdo->prepare("
            SELECT COUNT(*) as c FROM applications a
            JOIN internships i ON a.internship_id = i.id
            WHERE i.employer_id = ? AND a.status = 'Pending'
        ");
        $stmt->execute([$employerId]);
        $pendCount = $stmt->fetch()['c'];

        $stmt = $pdo->prepare("
            SELECT COUNT(*) as c FROM applications a
            JOIN internships i ON a.internship_id = i.id
            WHERE i.employer_id = ? AND a.status = 'Accepted'
        ");
        $stmt->execute([$employerId]);
        $accCount = $stmt->fetch()['c'];

        jsonResponse(['success' => true, 'stats' => [
            'postings' => $postCount,
            'applications' => $appCount,
            'pending' => $pendCount,
            'accepted' => $accCount
        ]]);

    default:
        jsonResponse(['success' => false, 'error' => 'Unknown action: ' . $action]);
}
