<?php
require 'db.php';

$action = $_POST['action'] ?? '';

switch ($action) {

    // ===================== STUDENT REGISTER =====================
    case 'register_student':
        $name  = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $pass  = $_POST['password'] ?? '';
        $age   = intval($_POST['age'] ?? 0);
        $loc   = trim($_POST['location'] ?? '');

        if (!$name || !$email || !$pass) {
            jsonResponse(['success' => false, 'error' => 'Full name, email and password are required.']);
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            jsonResponse(['success' => false, 'error' => 'Invalid email address.']);
        }
        if (strlen($pass) < 6) {
            jsonResponse(['success' => false, 'error' => 'Password must be at least 6 characters.']);
        }

        $stmt = $pdo->prepare("SELECT id FROM students WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            jsonResponse(['success' => false, 'error' => 'Email already registered.']);
        }

        $hash = password_hash($pass, PASSWORD_BCRYPT);
        $initials = implode('', array_map(fn($w) => strtoupper($w[0] ?? ''), explode(' ', $name)));
        $initials = substr($initials, 0, 2);

        $stmt = $pdo->prepare("INSERT INTO students (full_name, email, password, initials, age, location) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$name, $email, $hash, $initials, $age ?: null, $loc]);

        $_SESSION['student_id'] = $pdo->lastInsertId();
        jsonResponse(['success' => true, 'message' => 'Account created successfully!', 'redirect' => 'student/dashboard.html']);

    // ===================== EMPLOYER REGISTER =====================
    case 'register_employer':
        $company = trim($_POST['company_name'] ?? '');
        $email   = trim($_POST['email'] ?? '');
        $pass    = $_POST['password'] ?? '';
        $industry = trim($_POST['industry'] ?? '');

        if (!$company || !$email || !$pass) {
            jsonResponse(['success' => false, 'error' => 'Company name, email and password are required.']);
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            jsonResponse(['success' => false, 'error' => 'Invalid email address.']);
        }
        if (strlen($pass) < 6) {
            jsonResponse(['success' => false, 'error' => 'Password must be at least 6 characters.']);
        }

        $stmt = $pdo->prepare("SELECT id FROM employers WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            jsonResponse(['success' => false, 'error' => 'Email already registered.']);
        }

        $hash = password_hash($pass, PASSWORD_BCRYPT);

        $stmt = $pdo->prepare("INSERT INTO employers (company_name, email, password, industry) VALUES (?, ?, ?, ?)");
        $stmt->execute([$company, $email, $hash, $industry]);

        $_SESSION['employer_id'] = $pdo->lastInsertId();
        jsonResponse(['success' => true, 'message' => 'Company account created successfully!', 'redirect' => 'employer/dashboard.html']);

    // ===================== STUDENT LOGIN =====================
    case 'login_student':
        $email = trim($_POST['email'] ?? '');
        $pass  = $_POST['password'] ?? '';

        $stmt = $pdo->prepare("SELECT * FROM students WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($pass, $user['password'])) {
            jsonResponse(['success' => false, 'error' => 'Invalid email or password.']);
        }

        $_SESSION['student_id'] = $user['id'];
        jsonResponse(['success' => true, 'redirect' => 'student/dashboard.html']);

    // ===================== EMPLOYER LOGIN =====================
    case 'login_employer':
        $email = trim($_POST['email'] ?? '');
        $pass  = $_POST['password'] ?? '';

        $stmt = $pdo->prepare("SELECT * FROM employers WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($pass, $user['password'])) {
            jsonResponse(['success' => false, 'error' => 'Invalid email or password.']);
        }

        $_SESSION['employer_id'] = $user['id'];
        jsonResponse(['success' => true, 'redirect' => 'employer/dashboard.html']);

    // ===================== LOGOUT =====================
    case 'logout':
        session_destroy();
        jsonResponse(['success' => true, 'redirect' => 'index.html']);

    // ===================== CHECK SESSION =====================
    case 'check_session':
        $type = $_POST['type'] ?? '';
        if ($type === 'student' && !empty($_SESSION['student_id'])) {
            jsonResponse(['success' => true, 'user_id' => $_SESSION['student_id']]);
        }
        if ($type === 'employer' && !empty($_SESSION['employer_id'])) {
            jsonResponse(['success' => true, 'user_id' => $_SESSION['employer_id']]);
        }
        jsonResponse(['success' => false]);

    default:
        jsonResponse(['success' => false, 'error' => 'Unknown action']);
}
