
const USERS_S = [{email:'student@demo.com', pass:'pass123', name:'Alex Johnson', initials:'AJ'}];
const USERS_E = [{email:'employer@demo.com', pass:'pass123', name:'TechCorp HR'}];
 
let S = {
  user: null,
  skills: [{n:'Python',c:'Programming'},{n:'JavaScript',c:'Programming'},{n:'SQL',c:'Database'},{n:'Data Analysis',c:'Programming'}],
  certs: [{t:'Python for Everybody',i:'Coursera',d:'2024-05-01',u:''},{t:'MySQL Basics',i:'Oracle Academy',d:'2024-08-15',u:''}],
  projects: [{t:'Student Result Management System',d:'A PHP + MySQL web app for managing student grades.',s:'PHP, MySQL, Bootstrap',dt:'2024-01-15'}],
  quizScores: {Python: 87},
  applications: [{intern:'Python Backend Developer Intern',company:'TechCorp Solutions',date:'2026-04-26',status:'Pending'}],
  pendingInternId: null,
};
 
let INTERNSHIPS = [
  {id:1,title:'Python Backend Developer Intern',company:'TechCorp Solutions',domain:'Python',duration:'3 months',stipend:20000,skills:'Python, Django, REST APIs',desc:'Work on backend APIs and microservices. You will design, build, and maintain scalable Python services.',applicants:[{name:'Alex Johnson',score:87,status:'Pending',email:'alex@university.edu'}]},
  {id:2,title:'PHP Web Developer Intern',company:'WebEdge Digital',domain:'PHP',duration:'6 months',stipend:15000,skills:'PHP, Laravel, MySQL',desc:'Build and maintain client websites using PHP and the Laravel framework. Agile team environment.',applicants:[]},
  {id:3,title:'Java Full Stack Intern',company:'InfoSys Labs',domain:'Java',duration:'4 months',stipend:25000,skills:'Java, Spring Boot, React',desc:'Develop enterprise-grade applications using Java Spring Boot and React on the frontend.',applicants:[{name:'Sara Ali',score:90,status:'Accepted',email:'sara@uni.edu'}]},
  {id:4,title:'Database Administrator Intern',company:'DataFirst Corp',domain:'DBS',duration:'3 months',stipend:18000,skills:'SQL, MySQL, PostgreSQL',desc:'Design, manage, and optimise relational databases. Gain hands-on experience with production-level data.',applicants:[]},
];
let nextId = 5;
 
const QUIZ_BANK = {
  Python:[
    {q:"What is the output of: print(type([]))?",opts:["<class 'list'>","<class 'array'>","<class 'tuple'>","Error"],a:0},
    {q:"Which keyword is used to define a function in Python?",opts:["function","def","func","define"],a:1},
    {q:"What does len([1, 2, 3]) return?",opts:["2","3","4","Error"],a:1},
    {q:"Which of these is a valid Python dictionary?",opts:["{1,2,3}","[1:2,3:4]","{'a':1,'b':2}","(a=1,b=2)"],a:2},
    {q:"How do you start a comment in Python?",opts:["//","/*","#","--"],a:2},
    {q:"What does 'self' refer to in a Python class method?",opts:["A keyword","The current object instance","A built-in function","A module"],a:1},
    {q:"What does range(5) produce?",opts:["[1,2,3,4,5]","[0,1,2,3,4]","[0,1,2,3,4,5]","[1,2,3,4]"],a:1},
    {q:"Which list method removes and returns the last item?",opts:["remove()","delete()","pop()","drop()"],a:2},
    {q:"What does the 'import' keyword do in Python?",opts:["Defines a function","Loads a module","Creates a class","Exports code"],a:1},
    {q:"What is the result of: 10 // 3?",opts:["3.33","3","4","Error"],a:1},
  ],
  PHP:[
    {q:"How do you declare a variable in PHP?",opts:["var x","let x","$x","x ="],a:2},
    {q:"Which function outputs text in PHP?",opts:["console.log()","echo or print","System.out.println()","printf() only"],a:1},
    {q:"What is the correct way to end a PHP statement?",opts:[":",".",";","end"],a:2},
    {q:"How do you open a PHP block?",opts:["<php>","<?php","<script php>","[php]"],a:1},
    {q:"Which superglobal holds HTTP POST data?",opts:["$_GET","$_POST","$_FORM","$_DATA"],a:1},
    {q:"Which function connects to MySQL in modern PHP?",opts:["mysql_connect()","mysqli_connect()","connect_mysql()","db_connect()"],a:1},
    {q:"What does '==' compare vs '==='?",opts:["Same thing","== compares value only, === compares value and type","=== is for objects","None of the above"],a:1},
    {q:"Which function returns the number of array elements?",opts:["length()","size()","count()","len()"],a:2},
    {q:"How do you create an array in PHP?",opts:["array(1,2,3) or [1,2,3]","list(1,2,3)","new Array(1,2,3)","arr(1,2,3)"],a:0},
    {q:"Which PHP tag is used to embed PHP in HTML?",opts:["<php>...</php>","<?php ... ?>","<? ... ?>","<script type=php>"],a:1},
  ],
  Java:[
    {q:"What is the entry-point method in a Java application?",opts:["start()","main()","run()","init()"],a:1},
    {q:"Which keyword instantiates an object in Java?",opts:["create","make","new","object"],a:2},
    {q:"What does System.out.println() do?",opts:["Reads input","Prints a line to stdout","Exits the program","Imports a class"],a:1},
    {q:"What is a Java interface?",opts:["A class with implementation","A contract of abstract methods","A data type","A variable"],a:1},
    {q:"Which access modifier makes a member accessible everywhere?",opts:["private","protected","public","default"],a:2},
    {q:"What is inheritance in Java?",opts:["Copying code","A class acquiring properties of another","Method overloading","Data hiding"],a:1},
    {q:"What is the size of an int in Java?",opts:["2 bytes","4 bytes","8 bytes","Platform-dependent"],a:1},
    {q:"What does the 'final' keyword do when applied to a variable?",opts:["Makes it static","Prevents its value from being changed","Deletes it","Makes it global"],a:1},
    {q:"Which exception is thrown on null reference access?",opts:["NullException","NullPointerException","IllegalArgumentException","RuntimeException"],a:1},
    {q:"Which Java collection maintains insertion order and allows duplicates?",opts:["HashSet","TreeSet","ArrayList","HashMap"],a:2},
  ],
  DBS:[
    {q:"What does SQL stand for?",opts:["Structured Query Language","Simple Query Logic","Sequenced Query Lines","Standard Queue Language"],a:0},
    {q:"Which SQL command retrieves data from a table?",opts:["INSERT","UPDATE","SELECT","FETCH"],a:2},
    {q:"What is a PRIMARY KEY?",opts:["A foreign key","A unique identifier for each row","An index","A check constraint"],a:1},
    {q:"What does JOIN do in SQL?",opts:["Deletes rows","Combines rows from multiple tables","Creates a new table","Sorts results"],a:1},
    {q:"Which command removes all rows without deleting the table structure?",opts:["DROP","DELETE","TRUNCATE","REMOVE"],a:2},
    {q:"What is database normalization?",opts:["Adding more columns","Organising data to reduce redundancy","Backing up the database","Encrypting data"],a:1},
    {q:"What does NULL represent in a database?",opts:["Zero","Empty string","Unknown or missing value","False"],a:2},
    {q:"Which SQL keyword filters results after GROUP BY?",opts:["WHERE","HAVING","FILTER","AFTER"],a:1},
    {q:"What is the primary purpose of a database index?",opts:["Store images","Speed up query execution","Join tables","Encrypt data"],a:1},
    {q:"What is a FOREIGN KEY?",opts:["The primary key of the same table","A key referencing another table's primary key","An auto-increment column","A composite key"],a:1},
  ]
};
 
let qz = {lang:'', questions:[], idx:0, chosen:null, correct:0};
 
function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  if (id === 'student-dash') { renderFeatured(); renderApps(); renderNotifs(); updateQStatus(); }
  if (id === 'employer-dash') { refreshEDash(); }
}
 
function loginStudent() {
  const em = document.getElementById('s-email').value.trim();
  const pw = document.getElementById('s-pass').value;
  const u = USERS_S.find(x => x.email === em && x.pass === pw);
  const err = document.getElementById('s-err');
  if (!u) { err.style.display = 'block'; return; }
  err.style.display = 'none';
  S.user = u;
  document.getElementById('sn-uname').textContent = u.name;
  document.getElementById('s-greet').textContent = u.name.split(' ')[0];
  document.getElementById('s-av').textContent = u.initials;
  document.getElementById('p-disp-name').textContent = u.name;
  showScreen('student-dash');
}
 
function loginEmployer() {
  const em = document.getElementById('e-email').value.trim();
  const pw = document.getElementById('e-pass').value;
  const u = USERS_E.find(x => x.email === em && x.pass === pw);
  const err = document.getElementById('e-err');
  if (!u) { err.style.display = 'block'; return; }
  err.style.display = 'none';
  document.getElementById('en-uname').textContent = u.name;
  showScreen('employer-dash');
}
 
function sPg(pgId, navId) {
  document.querySelectorAll('#student-dash .page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('#student-dash .nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById(pgId).classList.add('active');
  document.getElementById(navId).classList.add('active');
  if (pgId === 's-skills') renderSkills();
  if (pgId === 's-certs') renderCerts();
  if (pgId === 's-projects') renderProjects();
  if (pgId === 's-browse') renderBrowse();
  if (pgId === 's-applied') renderApps();
  if (pgId === 's-notif') renderNotifs();
  if (pgId === 's-quiz-sel') updateQStatus();
  updateHomeStats();
}
 
function ePg(pgId, navId) {
  document.querySelectorAll('#employer-dash .page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('#employer-dash .nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById(pgId).classList.add('active');
  document.getElementById(navId).classList.add('active');
  if (pgId === 'e-home') refreshEDash();
  if (pgId === 'e-postings') renderEPostings();
  if (pgId === 'e-apps') renderEApps();
}
 
function updateHomeStats() {
  document.getElementById('h-skills-ct').textContent = S.skills.length;
  document.getElementById('h-cert-ct').textContent = S.certs.length;
  document.getElementById('h-app-ct').textContent = S.applications.length;
  const best = Object.values(S.quizScores);
  document.getElementById('h-best-score').textContent = best.length ? Math.max(...best) + '%' : '—';
}
 
function renderSkills() {
  const el = document.getElementById('skills-tags');
  if (!S.skills.length) { el.innerHTML = '<span class="text-muted">No skills yet. Add your first skill!</span>'; return; }
  el.innerHTML = S.skills.map((s,i) => `<span class="tag blue" style="font-size:13px; padding:5px 14px; cursor:default;">${s.n} <span style="opacity:0.65; font-size:11px;">${s.c}</span> <button onclick="S.skills.splice(${i},1); renderSkills()" style="background:none; border:none; cursor:pointer; margin-left:6px; color:inherit; opacity:0.6; font-size:13px; padding:0;">×</button></span>`).join('');
}
 
function addSkill() {
  const n = document.getElementById('mi-skill').value.trim();
  const c = document.getElementById('mi-skill-cat').value;
  if (!n) return;
  S.skills.push({n, c});
  closeM('m-skill');
  document.getElementById('mi-skill').value = '';
  renderSkills(); updateHomeStats();
}
 
function renderCerts() {
  const el = document.getElementById('certs-list');
  if (!S.certs.length) { el.innerHTML = '<p class="text-muted">No certifications yet.</p>'; return; }
  el.innerHTML = S.certs.map((c,i) => `<div class="flex justify-between items-center" style="padding:12px 0; border-bottom:1px solid var(--border);">
    <div><div class="fw-500">${c.t}</div><div class="text-sm text-muted mt-4">Issued by ${c.i}${c.d ? ' · ' + c.d : ''}</div></div>
    <button class="btn sm red" onclick="S.certs.splice(${i},1); renderCerts()">Remove</button>
  </div>`).join('');
}
 
function addCert() {
  const t = document.getElementById('mi-ct').value.trim();
  const i = document.getElementById('mi-ci').value.trim();
  if (!t || !i) return;
  S.certs.push({t, i, d: document.getElementById('mi-cd').value, u: document.getElementById('mi-cu').value});
  closeM('m-cert'); renderCerts(); updateHomeStats();
}
 
function renderProjects() {
  const el = document.getElementById('proj-list');
  if (!S.projects.length) { el.innerHTML = '<p class="text-muted">No projects yet. Add your first project!</p>'; return; }
  el.innerHTML = S.projects.map((p,i) => `<div class="intern-card">
    <div class="flex justify-between items-center mb-8">
      <div class="ic-title" style="margin:0;">${p.t}</div>
      <button class="btn sm red" onclick="S.projects.splice(${i},1); renderProjects()">Remove</button>
    </div>
    <p class="text-muted" style="font-size:13px; line-height:1.6; margin-bottom:10px;">${p.d || ''}</p>
    <div>${(p.s||'').split(',').filter(Boolean).map(x => `<span class="tag teal">${x.trim()}</span>`).join(' ')}</div>
  </div>`).join('');
}
 
function addProject() {
  const t = document.getElementById('mi-pt').value.trim();
  if (!t) return;
  S.projects.push({t, d: document.getElementById('mi-pd').value, s: document.getElementById('mi-ps').value, dt: document.getElementById('mi-pdate').value});
  closeM('m-proj'); renderProjects();
}
 
function renderBrowse() {
  const el = document.getElementById('browse-list');
  const q = (document.getElementById('s-search')?.value||'').toLowerCase();
  const dom = document.getElementById('s-filter')?.value||'';
  const list = INTERNSHIPS.filter(i => (!q || i.title.toLowerCase().includes(q) || i.domain.toLowerCase().includes(q)) && (!dom || i.domain === dom));
  if (!list.length) { el.innerHTML = '<p class="text-muted center" style="padding:2rem;">No internships found matching your search.</p>'; return; }
  el.innerHTML = list.map(i => {
    const qual = (S.quizScores[i.domain]||0) >= 80;
    const applied = S.applications.some(a => a.intern === i.title);
    return `<div class="intern-card">
      <div class="ic-company">${i.company}</div>
      <div class="ic-title">${i.title}</div>
      <div class="ic-meta">
        <span>📅 ${i.duration}</span>
        <span>💼 ${i.domain}</span>
        <span class="ic-stipend">PKR ${i.stipend.toLocaleString()}/month</span>
        <span>👥 ${i.applicants.length} applied</span>
      </div>
      <div class="ic-desc">${i.desc}</div>
      <div class="ic-skills">${i.skills.split(',').map(s => `<span class="tag gray">${s.trim()}</span>`).join(' ')}</div>
      <div class="ic-actions">
        ${applied
          ? '<span class="tag green">✓ Applied</span>'
          : qual
            ? `<button class="btn sm blue" onclick="openApply(${i.id})">Apply Now</button><span class="tag green">Quiz passed ✓</span>`
            : `<button class="btn sm" onclick="sPg('s-quiz-sel','sn-quiz')">Take ${i.domain} Quiz first</button><span class="tag amber">Score 80%+ required</span>`}
      </div>
    </div>`;
  }).join('');
}
 
function renderFeatured() {
  document.getElementById('featured-list').innerHTML = INTERNSHIPS.slice(0,2).map(i => {
    const qual = (S.quizScores[i.domain]||0) >= 80;
    return `<div class="intern-card">
      <div class="ic-company">${i.company}</div>
      <div class="ic-title">${i.title}</div>
      <div class="ic-meta"><span>📅 ${i.duration}</span><span>💼 ${i.domain}</span><span class="ic-stipend">PKR ${i.stipend.toLocaleString()}/month</span></div>
      <div class="ic-actions">
        ${qual ? `<button class="btn sm blue" onclick="openApply(${i.id})">Apply Now</button>` : `<button class="btn sm" onclick="sPg('s-quiz-sel','sn-quiz')">Take ${i.domain} Quiz</button>`}
      </div>
    </div>`;
  }).join('');
}
 
function renderApps() {
  const el = document.getElementById('apps-tbody');
  if (!S.applications.length) { el.innerHTML = '<tr><td colspan="4" class="text-muted center" style="padding:2rem;">No applications yet.</td></tr>'; return; }
  const colorMap = {Pending:'blue', Accepted:'green', Rejected:'red', 'Not Eligible':'amber'};
  el.innerHTML = S.applications.map(a => `<tr>
    <td class="fw-500">${a.intern}</td>
    <td>${a.company}</td>
    <td>${a.date}</td>
    <td><span class="tag ${colorMap[a.status]||'gray'}">${a.status}</span></td>
  </tr>`).join('');
}
 
function renderNotifs() {
  const items = [
    {bg:'var(--green-lt)',ico:'✓',t:'Quiz passed — Python',s:'Score: 87% · 2 days ago'},
    {bg:'var(--blue-lt)',ico:'📋',t:'Application submitted — TechCorp Python Intern',s:'Status: Pending · 3 days ago'},
    {bg:'var(--amber-lt)',ico:'📢',t:'New internship posted — Java Full Stack Intern',s:'InfoSys Labs · 4 days ago'},
    {bg:'var(--teal-lt)',ico:'🏅',t:'Certificate available — Python completion',s:'Issued automatically · 5 days ago'},
  ];
  document.getElementById('notif-card').innerHTML = items.map(n => `<div class="notif-row">
    <div class="ni-icon" style="background:${n.bg};">${n.ico}</div>
    <div><div class="fw-500">${n.t}</div><div class="text-sm text-muted mt-4">${n.s}</div></div>
  </div>`).join('');
}
 
function updateQStatus() {
  ['Python','PHP','Java','DBS'].forEach(lang => {
    const el = document.getElementById('qs-' + lang);
    if (!el) return;
    const sc = S.quizScores[lang];
    if (sc !== undefined) {
      el.innerHTML = sc >= 80 ? `<span class="tag green">Passed: ${sc}%</span>` : `<span class="tag red">Failed: ${sc}% — retry</span>`;
    } else {
      el.innerHTML = `<span class="tag gray">Not attempted</span>`;
    }
  });
}
 
function openApply(id) {
  const intern = INTERNSHIPS.find(i => i.id === id);
  S.pendingInternId = id;
  const qual = (S.quizScores[intern.domain]||0) >= 80;
  document.getElementById('ma-title').textContent = 'Apply: ' + intern.title;
  document.getElementById('ma-sub').textContent = qual
    ? `You've qualified with a ${S.quizScores[intern.domain]}% score in ${intern.domain}. Submit your application to ${intern.company}?`
    : `This internship requires a passing score (≥80%) in ${intern.domain}.`;
  document.getElementById('ma-warn').style.display = qual ? 'none' : 'block';
  document.getElementById('ma-confirm').style.display = qual ? '' : 'none';
  openM('m-apply');
}
 
function doApply() {
  const intern = INTERNSHIPS.find(i => i.id === S.pendingInternId);
  if (!intern) return;
  const already = S.applications.some(a => a.intern === intern.title);
  if (already) { closeM('m-apply'); return; }
  S.applications.push({intern: intern.title, company: intern.company, date: new Date().toISOString().split('T')[0], status: 'Pending'});
  intern.applicants.push({name: S.user?.name||'Student', score: S.quizScores[intern.domain], status: 'Pending', email: S.user?.email||''});
  closeM('m-apply');
  sPg('s-applied', 'sn-applied');
}
 
function saveProfile() {
  const name = document.getElementById('pf-name').value;
  const email = document.getElementById('pf-email').value;
  const loc = document.getElementById('pf-loc').value;
  document.getElementById('p-disp-name').textContent = name;
  document.getElementById('p-disp-email').textContent = email;
  document.getElementById('p-disp-loc').textContent = loc;
  document.getElementById('sn-uname').textContent = name;
  document.getElementById('s-greet').textContent = name.split(' ')[0];
  const init = name.split(' ').map(w=>w[0]).join('').toUpperCase().slice(0,2);
  document.getElementById('s-av').textContent = init;
  const msg = document.getElementById('p-save-msg');
  msg.style.display = 'block'; setTimeout(()=> msg.style.display='none', 2500);
}
 
// QUIZ
function startQuiz(lang) {
  qz = {lang, questions: [...QUIZ_BANK[lang]], idx: 0, chosen: null, correct: 0};
  document.getElementById('qz-lang').textContent = lang + ' Quiz';
  sPg('s-quiz-active', 'sn-quiz');
  renderQ();
}
 
function renderQ() {
  const q = qz.questions[qz.idx];
  const total = qz.questions.length;
  document.getElementById('qz-prog-txt').textContent = `Q ${qz.idx + 1} of ${total}`;
  document.getElementById('qz-fill').style.width = ((qz.idx + 1) / total * 100) + '%';
  document.getElementById('qz-q').textContent = q.q;
  document.getElementById('qz-opts').innerHTML = q.opts.map((opt, i) =>
    `<div class="opt" id="opt${i}" onclick="pickOpt(${i})"><div class="opt-dot" id="dot${i}"></div>${opt}</div>`
  ).join('');
  const nb = document.getElementById('qz-next');
  nb.disabled = true;
  nb.textContent = qz.idx === qz.questions.length - 1 ? 'See Result' : 'Next →';
  qz.chosen = null;
}
 
function pickOpt(idx) {
  if (qz.chosen !== null) return;
  qz.chosen = idx;
  const q = qz.questions[qz.idx];
  document.querySelectorAll('.opt').forEach((el, i) => {
    if (i === q.a) { el.classList.add('ok'); }
    else if (i === idx) { el.classList.add('bad'); }
  });
  if (idx === q.a) qz.correct++;
  document.getElementById('qz-next').disabled = false;
}
 
function nextQ() {
  if (qz.chosen === null) return;
  if (qz.idx < qz.questions.length - 1) { qz.idx++; renderQ(); }
  else showQResult();
}
 
function showQResult() {
  const score = Math.round((qz.correct / qz.questions.length) * 100);
  S.quizScores[qz.lang] = score;
  const pass = score >= 80;
  const ring = document.getElementById('qz-ring');
  ring.className = 'score-ring ' + (pass ? 'pass' : 'fail');
  document.getElementById('qz-pct').textContent = score + '%';
  document.getElementById('qz-frac').textContent = `${qz.correct} / ${qz.questions.length} correct`;
  document.getElementById('qz-rtitle').textContent = pass ? '🎉 Congratulations — you passed!' : '📚 Keep practising!';
  document.getElementById('qz-rmsg').textContent = pass
    ? `Excellent work! You scored ${score}% on the ${qz.lang} quiz. You're now eligible to apply for ${qz.lang} internships.`
    : `You scored ${score}% on the ${qz.lang} quiz. You need at least 80% to qualify. Review your skills and try again — you've got this!`;
  sPg('s-quiz-result', 'sn-quiz');
  updateHomeStats();
}
 
// EMPLOYER
function refreshEDash() {
  const total = INTERNSHIPS.length;
  const allApps = INTERNSHIPS.reduce((s,i) => s + i.applicants.length, 0);
  const pend = INTERNSHIPS.reduce((s,i) => s + i.applicants.filter(a=>a.status==='Pending').length, 0);
  const acc = INTERNSHIPS.reduce((s,i) => s + i.applicants.filter(a=>a.status==='Accepted').length, 0);
  document.getElementById('e-post-ct').textContent = total;
  document.getElementById('e-app-ct').textContent = allApps;
  document.getElementById('e-pend-ct').textContent = pend;
  document.getElementById('e-acc-ct').textContent = acc;
  document.getElementById('e-home-list').innerHTML = INTERNSHIPS.map(i => `<div class="flex justify-between items-center" style="padding:12px 0; border-bottom:1px solid var(--border);">
    <div>
      <div class="fw-500">${i.title}</div>
      <div class="text-sm text-muted mt-4">${i.domain} · ${i.duration} · ${i.applicants.length} applicant(s)</div>
    </div>
    <span class="tag green">Active</span>
  </div>`).join('');
}
 
function renderEPostings() {
  const el = document.getElementById('e-post-list');
  const none = document.getElementById('no-posts');
  if (!INTERNSHIPS.length) { el.innerHTML = ''; none.style.display='block'; return; }
  none.style.display='none';
  el.innerHTML = INTERNSHIPS.map(i => `<div class="intern-card">
    <div class="ic-company">${i.company}</div>
    <div class="ic-title">${i.title}</div>
    <div class="ic-meta">
      <span>💼 ${i.domain}</span><span>📅 ${i.duration}</span>
      <span class="ic-stipend">PKR ${i.stipend.toLocaleString()}/month</span>
      <span>👥 ${i.applicants.length} applicant(s)</span>
    </div>
    <div class="ic-desc">${i.desc}</div>
    <div class="ic-skills">${i.skills.split(',').map(s=>`<span class="tag gray">${s.trim()}</span>`).join(' ')}</div>
    <div class="ic-actions mt-8">
      <button class="btn sm red" onclick="deletePost(${i.id})">Delete posting</button>
      <span class="tag green">Active</span>
    </div>
  </div>`).join('');
}
 
function deletePost(id) {
  if (!confirm('Delete this internship posting?')) return;
  INTERNSHIPS = INTERNSHIPS.filter(i => i.id !== id);
  renderEPostings(); refreshEDash();
}
 
function postJob() {
  const title = document.getElementById('ni-title').value.trim();
  const domain = document.getElementById('ni-domain').value;
  const dur = document.getElementById('ni-dur').value.trim();
  const stipend = parseInt(document.getElementById('ni-stipend').value)||0;
  const skills = document.getElementById('ni-skills').value.trim();
  const desc = document.getElementById('ni-desc').value.trim();
  const company = document.getElementById('cp-name').value || 'Your Company';
  const err = document.getElementById('ni-err');
  const ok = document.getElementById('ni-ok');
  if (!title || !dur || !desc) { err.style.display='block'; return; }
  err.style.display='none';
  INTERNSHIPS.push({id: nextId++, title, company, domain, duration: dur, stipend, skills, desc, applicants:[]});
  ['ni-title','ni-dur','ni-stipend','ni-skills','ni-desc'].forEach(id => document.getElementById(id).value = '');
  ok.style.display='block'; setTimeout(()=>ok.style.display='none', 2500);
  setTimeout(()=> ePg('e-postings','en-post'), 800);
}
 
function renderEApps() {
  const rows = [];
  INTERNSHIPS.forEach(i => {
    i.applicants.forEach((a, ai) => {
      const sc = a.score||0;
      const colorMap = {Pending:'blue', Accepted:'green', Rejected:'red'};
      rows.push(`<tr>
        <td><div class="fw-500">${a.name}</div><div class="text-sm text-muted">${a.email||''}</div></td>
        <td>${i.title}</td>
        <td><span class="tag ${sc>=80?'green':'red'}">${sc}%</span></td>
        <td><span class="tag ${colorMap[a.status]||'gray'}">${a.status}</span></td>
        <td class="flex gap-8">
          <button class="btn sm teal" onclick="setStatus(${i.id},${ai},'Accepted')">Accept</button>
          <button class="btn sm red" onclick="setStatus(${i.id},${ai},'Rejected')">Reject</button>
        </td>
      </tr>`);
    });
  });
  document.getElementById('e-apps-body').innerHTML = rows.join('') || '<tr><td colspan="5" class="text-muted center" style="padding:2rem;">No applications yet.</td></tr>';
}
 
function setStatus(internId, appIdx, status) {
  const intern = INTERNSHIPS.find(i => i.id === internId);
  if (!intern) return;
  intern.applicants[appIdx].status = status;
  const app = S.applications.find(a => a.intern === intern.title);
  if (app) app.status = status;
  renderEApps(); refreshEDash();
}
 
// MODALS
function openM(id) { document.getElementById(id).classList.add('open'); }
function closeM(id) { document.getElementById(id).classList.remove('open'); }
document.querySelectorAll('.overlay').forEach(o => {
  o.addEventListener('click', e => { if (e.target === o) o.classList.remove('open'); });
});
 
// Enter key login
document.addEventListener('keydown', e => {
  if (e.key === 'Enter') {
    const screen = document.querySelector('.screen.active');
    if (screen?.id === 'student-auth') loginStudent();
    else if (screen?.id === 'employer-auth') loginEmployer();
  }
});
 
updateHomeStats();
