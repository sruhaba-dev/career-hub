<?php
require 'db.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';

// All student actions require authentication
if (!in_array($action, [])) {
    requireAuth('student');
}

$studentId = $_SESSION['student_id'] ?? 0;

switch ($action) {

    // ===================== PROFILE =====================
    case 'get_profile':
        $stmt = $pdo->prepare("SELECT id, full_name, email, initials, age, location, resume_url, profile_pic FROM students WHERE id = ?");
        $stmt->execute([$studentId]);
        $profile = $stmt->fetch();
        jsonResponse(['success' => true, 'profile' => $profile]);

    case 'update_profile':
        $name   = trim($_POST['full_name'] ?? '');
        $email  = trim($_POST['email'] ?? '');
        $age    = intval($_POST['age'] ?? 0);
        $loc    = trim($_POST['location'] ?? '');
        $resume = trim($_POST['resume_url'] ?? '');
        $pic    = trim($_POST['profile_pic'] ?? '');

        $initials = implode('', array_map(fn($w) => strtoupper($w[0] ?? ''), explode(' ', $name)));
        $initials = substr($initials, 0, 2);

        $stmt = $pdo->prepare("UPDATE students SET full_name = ?, email = ?, age = ?, location = ?, resume_url = ?, profile_pic = ?, initials = ? WHERE id = ?");
        $stmt->execute([$name, $email, $age ?: null, $loc, $resume, $pic, $initials, $studentId]);
        jsonResponse(['success' => true, 'message' => 'Profile saved successfully!']);

    // ===================== SKILLS =====================
    case 'get_skills':
        $stmt = $pdo->prepare("SELECT * FROM skills WHERE student_id = ? ORDER BY created_at DESC");
        $stmt->execute([$studentId]);
        jsonResponse(['success' => true, 'skills' => $stmt->fetchAll()]);

    case 'add_skill':
        $name = trim($_POST['name'] ?? '');
        $cat  = trim($_POST['category'] ?? 'Other');
        if (!$name) jsonResponse(['success' => false, 'error' => 'Skill name required']);
        $stmt = $pdo->prepare("INSERT INTO skills (student_id, name, category) VALUES (?, ?, ?)");
        $stmt->execute([$studentId, $name, $cat]);
        jsonResponse(['success' => true]);

    case 'delete_skill':
        $id = intval($_POST['id'] ?? 0);
        $stmt = $pdo->prepare("DELETE FROM skills WHERE id = ? AND student_id = ?");
        $stmt->execute([$id, $studentId]);
        jsonResponse(['success' => true]);

    // ===================== CERTIFICATIONS =====================
    case 'get_certs':
        $stmt = $pdo->prepare("SELECT * FROM certifications WHERE student_id = ? ORDER BY created_at DESC");
        $stmt->execute([$studentId]);
        jsonResponse(['success' => true, 'certs' => $stmt->fetchAll()]);

    case 'add_cert':
        $title = trim($_POST['title'] ?? '');
        $issuer = trim($_POST['issuer'] ?? '');
        $date  = $_POST['issue_date'] ?? null;
        $url   = trim($_POST['cert_url'] ?? '');
        if (!$title || !$issuer) jsonResponse(['success' => false, 'error' => 'Title and issuer required']);
        $stmt = $pdo->prepare("INSERT INTO certifications (student_id, title, issuer, issue_date, cert_url) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$studentId, $title, $issuer, $date ?: null, $url]);
        jsonResponse(['success' => true]);

    case 'delete_cert':
        $id = intval($_POST['id'] ?? 0);
        $stmt = $pdo->prepare("DELETE FROM certifications WHERE id = ? AND student_id = ?");
        $stmt->execute([$id, $studentId]);
        jsonResponse(['success' => true]);

    // ===================== PROJECTS =====================
    case 'get_projects':
        $stmt = $pdo->prepare("SELECT * FROM projects WHERE student_id = ? ORDER BY created_at DESC");
        $stmt->execute([$studentId]);
        jsonResponse(['success' => true, 'projects' => $stmt->fetchAll()]);

    case 'add_project':
        $title = trim($_POST['title'] ?? '');
        $desc  = trim($_POST['description'] ?? '');
        $stack = trim($_POST['tech_stack'] ?? '');
        $date  = $_POST['project_date'] ?? null;
        if (!$title) jsonResponse(['success' => false, 'error' => 'Project title required']);
        $stmt = $pdo->prepare("INSERT INTO projects (student_id, title, description, tech_stack, project_date) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$studentId, $title, $desc, $stack, $date ?: null]);
        jsonResponse(['success' => true]);

    case 'delete_project':
        $id = intval($_POST['id'] ?? 0);
        $stmt = $pdo->prepare("DELETE FROM projects WHERE id = ? AND student_id = ?");
        $stmt->execute([$id, $studentId]);
        jsonResponse(['success' => true]);

    // ===================== QUIZ SCORES =====================
    case 'get_quiz_scores':
        $stmt = $pdo->prepare("SELECT domain, score FROM quiz_scores WHERE student_id = ?");
        $stmt->execute([$studentId]);
        $scores = [];
        foreach ($stmt->fetchAll() as $row) {
            $scores[$row['domain']] = intval($row['score']);
        }
        jsonResponse(['success' => true, 'scores' => $scores]);

    case 'submit_quiz':
        $domain = trim($_POST['domain'] ?? '');
        $score  = intval($_POST['score'] ?? 0);
        if (!$domain) jsonResponse(['success' => false, 'error' => 'Domain required']);
        $stmt = $pdo->prepare("INSERT INTO quiz_scores (student_id, domain, score) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE score = GREATEST(score, VALUES(score)), taken_at = CURRENT_TIMESTAMP");
        $stmt->execute([$studentId, $domain, $score]);
        jsonResponse(['success' => true]);

    // ===================== INTERNSHIPS =====================
    case 'get_internships':
        $stmt = $pdo->query("
            SELECT i.*, e.company_name,
                (SELECT COUNT(*) FROM applications a WHERE a.internship_id = i.id) as applicant_count
            FROM internships i
            JOIN employers e ON i.employer_id = e.id
            ORDER BY i.created_at DESC
        ");
        jsonResponse(['success' => true, 'internships' => $stmt->fetchAll()]);

    // ===================== APPLICATIONS =====================
    case 'get_applications':
        $stmt = $pdo->prepare("SELECT a.id, a.student_id, a.internship_id, a.status, a.applied_at, i.title as intern_title, i.company_name, i.domain FROM applications a JOIN internships i ON a.internship_id = i.id WHERE a.student_id = ? ORDER BY a.applied_at DESC");
        $stmt->execute([$studentId]);
        jsonResponse(['success' => true, 'applications' => $stmt->fetchAll()]);

    case 'apply':
        $internshipId = intval($_POST['internship_id'] ?? 0);
        if (!$internshipId) jsonResponse(['success' => false, 'error' => 'Internship ID required']);

        // Check if already applied
        $stmt = $pdo->prepare("SELECT id FROM applications WHERE student_id = ? AND internship_id = ?");
        $stmt->execute([$studentId, $internshipId]);
        if ($stmt->fetch()) {
            jsonResponse(['success' => false, 'error' => 'You have already applied for this internship.']);
        }

        $coverLetter    = trim($_POST['cover_letter'] ?? '');
        $phone          = trim($_POST['phone'] ?? '');
        $expectedSalary = trim($_POST['expected_salary'] ?? '');
        $projectIds     = trim($_POST['selected_project_ids'] ?? '');
        $certIds        = trim($_POST['selected_cert_ids'] ?? '');

        // Validate required fields
        if (empty($phone)) {
            jsonResponse(['success' => false, 'error' => 'Phone number is required.']);
        }
        if (empty($coverLetter)) {
            jsonResponse(['success' => false, 'error' => 'Cover letter is required.']);
        }
        // Validate: at least one project and one certificate required
        if (empty($projectIds)) {
            jsonResponse(['success' => false, 'error' => 'Please select at least one project to showcase.']);
        }
        if (empty($certIds)) {
            jsonResponse(['success' => false, 'error' => 'Please select at least one certificate to include.']);
        }

        $expectedSalaryInt = intval($expectedSalary) ?: null;
        try {
            $stmt = $pdo->prepare("INSERT INTO applications (student_id, internship_id, cover_letter, phone, expected_salary, selected_project_ids, selected_cert_ids) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$studentId, $internshipId, $coverLetter, $phone, $expectedSalaryInt, $projectIds, $certIds]);
            jsonResponse(['success' => true]);
        } catch (PDOException $e) {
            // Column may not exist yet — try without expected_salary for backward compat
            if (strpos($e->getMessage(), 'expected_salary') !== false) {
                $stmt = $pdo->prepare("INSERT INTO applications (student_id, internship_id, cover_letter, phone, selected_project_ids, selected_cert_ids) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$studentId, $internshipId, $coverLetter, $phone, $projectIds, $certIds]);
                jsonResponse(['success' => true]);
            } else {
                jsonResponse(['success' => false, 'error' => 'Could not submit application: ' . $e->getMessage()]);
            }
        }


    // ===================== RECENT ACTIVITY =====================
    case 'get_recent_activity':
        $activity = [];

        $stmt = $pdo->prepare("SELECT domain, score, taken_at FROM quiz_scores WHERE student_id = ? ORDER BY taken_at DESC LIMIT 5");
        $stmt->execute([$studentId]);
        foreach ($stmt->fetchAll() as $row) {
            $activity[] = [
                'type'  => $row['score'] >= 80 ? 'quiz_pass' : 'quiz_fail',
                'title' => 'Quiz ' . ($row['score'] >= 80 ? 'passed' : 'attempted') . ' -- ' . $row['domain'],
                'sub'   => 'Score: ' . $row['score'] . '%',
                'time'  => $row['taken_at']
            ];
        }

        $stmt = $pdo->prepare("SELECT i.title, i.company_name, a.status, a.applied_at FROM applications a JOIN internships i ON a.internship_id = i.id WHERE a.student_id = ? ORDER BY a.applied_at DESC LIMIT 5");
        $stmt->execute([$studentId]);
        foreach ($stmt->fetchAll() as $row) {
            $activity[] = [
                'type'  => 'application',
                'title' => 'Application submitted -- ' . $row['title'],
                'sub'   => $row['company_name'] . ' · Status: ' . $row['status'],
                'time'  => $row['applied_at']
            ];
        }

        usort($activity, function($x, $y) { return strtotime($y['time']) - strtotime($x['time']); });
        jsonResponse(['success' => true, 'activity' => array_slice($activity, 0, 8)]);

    // ===================== NOTIFICATIONS =====================
    case 'get_notifications':
        $notifs = [];

        $stmt = $pdo->query("SELECT i.id, i.title, i.company_name, i.domain, i.created_at FROM internships i ORDER BY i.created_at DESC LIMIT 10");
        foreach ($stmt->fetchAll() as $row) {
            $notifs[] = [
                'type'         => 'new_post',
                'title'        => 'New internship posted -- ' . $row['title'],
                'sub'          => $row['company_name'] . ' · ' . $row['domain'],
                'time'         => $row['created_at'],
                'internship_id'=> (int)$row['id']
            ];
        }

        $stmt = $pdo->prepare("SELECT i.title, i.company_name, a.status, a.applied_at FROM applications a JOIN internships i ON a.internship_id = i.id WHERE a.student_id = ? AND a.status != 'Pending' ORDER BY a.applied_at DESC LIMIT 5");
        $stmt->execute([$studentId]);
        foreach ($stmt->fetchAll() as $row) {
            $notifs[] = [
                'type'          => 'app_status',
                'title'         => 'Application ' . strtolower($row['status']) . ' -- ' . $row['title'],
                'sub'           => $row['company_name'],
                'time'          => $row['applied_at'],
                'internship_id' => null
            ];
        }

        $stmt = $pdo->prepare("SELECT domain, score, taken_at FROM quiz_scores WHERE student_id = ? AND score >= 80 ORDER BY taken_at DESC LIMIT 5");
        $stmt->execute([$studentId]);
        foreach ($stmt->fetchAll() as $row) {
            $notifs[] = [
                'type'          => 'quiz_pass',
                'title'         => 'Quiz passed -- ' . $row['domain'],
                'sub'           => 'Score: ' . $row['score'] . '% · You are now eligible to apply',
                'time'          => $row['taken_at'],
                'internship_id' => null
            ];
        }

        usort($notifs, function($x, $y) { return strtotime($y['time']) - strtotime($x['time']); });
        jsonResponse(['success' => true, 'notifications' => array_slice($notifs, 0, 15)]);

    // ===================== DASHBOARD STATS =====================
    case 'get_stats':
        $skills = $pdo->prepare("SELECT COUNT(*) as c FROM skills WHERE student_id = ?");
        $skills->execute([$studentId]);
        $skillCount = $skills->fetch()['c'];

        $certs = $pdo->prepare("SELECT COUNT(*) as c FROM certifications WHERE student_id = ?");
        $certs->execute([$studentId]);
        $certCount = $certs->fetch()['c'];

        $apps = $pdo->prepare("SELECT COUNT(*) as c FROM applications WHERE student_id = ?");
        $apps->execute([$studentId]);
        $appCount = $apps->fetch()['c'];

        $stmt = $pdo->prepare("SELECT MAX(score) as best FROM quiz_scores WHERE student_id = ?");
        $stmt->execute([$studentId]);
        $best = $stmt->fetch()['best'];

        jsonResponse(['success' => true, 'stats' => [
            'skills' => $skillCount,
            'certs' => $certCount,
            'applications' => $appCount,
            'best_score' => $best ? $best . '%' : '—'
        ]]);

    default:
        jsonResponse(['success' => false, 'error' => 'Unknown action: ' . $action]);
}
