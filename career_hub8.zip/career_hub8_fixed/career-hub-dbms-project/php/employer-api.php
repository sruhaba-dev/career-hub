<?php
require 'db.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';

// All employer actions require authentication
requireAuth('employer');

$employerId = $_SESSION['employer_id'] ?? 0;

switch ($action) {

    // ===================== PROFILE =====================
    case 'get_profile':
        $stmt = $pdo->prepare("SELECT id, company_name, email, industry, website, description FROM employers WHERE id = ?");
        $stmt->execute([$employerId]);
        $profile = $stmt->fetch();
        jsonResponse(['success' => true, 'profile' => $profile]);

    case 'update_profile':
        $company = trim($_POST['company_name'] ?? '');
        $email   = trim($_POST['email'] ?? '');
        $industry = trim($_POST['industry'] ?? '');
        $website = trim($_POST['website'] ?? '');
        $desc    = trim($_POST['description'] ?? '');

        $stmt = $pdo->prepare("UPDATE employers SET company_name = ?, email = ?, industry = ?, website = ?, description = ? WHERE id = ?");
        $stmt->execute([$company, $email, $industry, $website, $desc, $employerId]);
        jsonResponse(['success' => true, 'message' => 'Profile saved successfully!']);

    // ===================== POSTINGS =====================
    case 'get_postings':
        $stmt = $pdo->prepare("
            SELECT i.*,
                (SELECT COUNT(*) FROM applications a WHERE a.internship_id = i.id) as applicant_count
            FROM internships i
            WHERE i.employer_id = ?
            ORDER BY i.created_at DESC
        ");
        $stmt->execute([$employerId]);
        jsonResponse(['success' => true, 'postings' => $stmt->fetchAll()]);

    case 'add_posting':
        $title    = trim($_POST['title'] ?? '');
        $domain   = trim($_POST['domain'] ?? '');
        $duration = trim($_POST['duration'] ?? '');
        $stipend  = intval($_POST['stipend'] ?? 0);
        $skills   = trim($_POST['skills'] ?? '');
        $desc     = trim($_POST['description'] ?? '');

        if (!$title || !$domain || !$duration || !$desc) {
            jsonResponse(['success' => false, 'error' => 'Please fill all required fields.']);
        }

        // Get company name from employer profile
        $stmt = $pdo->prepare("SELECT company_name FROM employers WHERE id = ?");
        $stmt->execute([$employerId]);
        $company = $stmt->fetch()['company_name'] ?? 'Your Company';

        $stmt = $pdo->prepare("INSERT INTO internships (employer_id, title, company_name, domain, duration, stipend, skills, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$employerId, $title, $company, $domain, $duration, $stipend, $skills, $desc]);
        jsonResponse(['success' => true]);

    case 'delete_posting':
        $id = intval($_POST['id'] ?? 0);
        $stmt = $pdo->prepare("DELETE FROM internships WHERE id = ? AND employer_id = ?");
        $stmt->execute([$id, $employerId]);
        jsonResponse(['success' => true]);

    // ===================== APPLICATIONS =====================
    case 'get_applications':
        $stmt = $pdo->prepare("
            SELECT a.id, a.student_id, a.internship_id, a.status, a.applied_at,
                   s.full_name, s.email, s.initials,
                   i.title as internship_title, i.domain,
                   qs.score as quiz_score
            FROM applications a
            JOIN students s ON a.student_id = s.id
            JOIN internships i ON a.internship_id = i.id
            LEFT JOIN quiz_scores qs ON qs.student_id = s.id AND qs.domain = i.domain
            WHERE i.employer_id = ?
            ORDER BY a.applied_at DESC
        ");
        $stmt->execute([$employerId]);
        jsonResponse(['success' => true, 'applications' => $stmt->fetchAll()]);

    case 'update_application_status':
        $appId  = intval($_POST['application_id'] ?? 0);
        $status = trim($_POST['status'] ?? '');
        if (!$appId || !in_array($status, ['Pending', 'Accepted', 'Rejected'])) {
            jsonResponse(['success' => false, 'error' => 'Invalid request']);
        }
        $stmt = $pdo->prepare("UPDATE applications SET status = ? WHERE id = ? AND internship_id IN (SELECT id FROM internships WHERE employer_id = ?)");
        $stmt->execute([$status, $appId, $employerId]);
        jsonResponse(['success' => true]);

    // ===================== DASHBOARD STATS =====================
    case 'get_stats':
        $postings = $pdo->prepare("SELECT COUNT(*) as c FROM internships WHERE employer_id = ?");
        $postings->execute([$employerId]);
        $postCount = $postings->fetch()['c'];

        $stmt = $pdo->prepare("
            SELECT COUNT(*) as c FROM applications a
            JOIN internships i ON a.internship_id = i.id
            WHERE i.employer_id = ?
        ");
        $stmt->execute([$employerId]);
        $appCount = $stmt->fetch()['c'];

        $stmt = $pdo->prepare("
            SELECT COUNT(*) as c FROM applications a
            JOIN internships i ON a.internship_id = i.id
            WHERE i.employer_id = ? AND a.status = 'Pending'
        ");
        $stmt->execute([$employerId]);
        $pendCount = $stmt->fetch()['c'];

        $stmt = $pdo->prepare("
            SELECT COUNT(*) as c FROM applications a
            JOIN internships i ON a.internship_id = i.id
            WHERE i.employer_id = ? AND a.status = 'Accepted'
        ");
        $stmt->execute([$employerId]);
        $accCount = $stmt->fetch()['c'];

        jsonResponse(['success' => true, 'stats' => [
            'postings' => $postCount,
            'applications' => $appCount,
            'pending' => $pendCount,
            'accepted' => $accCount
        ]]);

    default:
        jsonResponse(['success' => false, 'error' => 'Unknown action: ' . $action]);
}
