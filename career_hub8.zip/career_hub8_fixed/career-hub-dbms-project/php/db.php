<?php
// Career Hub - Database Connection
// Update these credentials to match your MySQL setup

$host = 'localhost';
$db   = 'career_hub';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=$charset", $user, $pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Database connection failed']);
    exit;
}

session_start();
header('Content-Type: application/json');

function jsonResponse($data) {
    echo json_encode($data);
    exit;
}

function requireAuth($type) {
    if ($type === 'student' && empty($_SESSION['student_id'])) {
        jsonResponse(['success' => false, 'error' => 'Unauthorized']);
    }
    if ($type === 'employer' && empty($_SESSION['employer_id'])) {
        jsonResponse(['success' => false, 'error' => 'Unauthorized']);
    }
}
