-- ============================================================
-- Career Hub - Migration Fix
-- Run this in phpMyAdmin if your applications table already
-- exists and "Submit Application" gives a network error.
-- ============================================================

USE career_hub;

ALTER TABLE applications
  ADD COLUMN IF NOT EXISTS cover_letter TEXT DEFAULT '',
  ADD COLUMN IF NOT EXISTS phone VARCHAR(30) DEFAULT '',
  ADD COLUMN IF NOT EXISTS expected_salary INT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS selected_project_ids VARCHAR(255) DEFAULT '',
  ADD COLUMN IF NOT EXISTS selected_cert_ids VARCHAR(255) DEFAULT '';

-- Verify columns were added:
DESCRIBE applications;
