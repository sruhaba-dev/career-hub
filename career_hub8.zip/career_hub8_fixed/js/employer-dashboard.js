// ===================== AUTH CHECK =====================
(async function() {
  try {
    const r = await fetch('../php/auth.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ action: 'check_session', type: 'employer' })
    });
    const d = await r.json();
    if (!d.success) window.location.href = '../employer/login.html';
    else loadDashboard();
  } catch(e) {
    window.location.href = '../employer/login.html';
  }
})();

function logout() {
  fetch('../php/auth.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ action: 'logout' })
  }).then(() => window.location.href = '../index.html');
}

// ===================== DATA STATE =====================
let profile = {};
let postings = [];
let applications = [];

function api(action, params = {}) {
  const fd = new URLSearchParams({ action, ...params });
  return fetch('../php/employer-api.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: fd
  }).then(r => r.json());
}

async function loadDashboard() {
  try {
    const [p, po, a, st] = await Promise.all([
      api('get_profile').catch(() => ({ success: false })),
      api('get_postings').catch(() => ({ success: false })),
      api('get_applications').catch(() => ({ success: false })),
      api('get_stats').catch(() => ({ success: false }))
    ]);

    if (p.success) profile = p.profile;
    if (po.success) postings = po.postings || [];
    if (a.success) applications = a.applications || [];

    document.getElementById('en-uname').textContent = profile.company_name || 'Employer';

    if (st && st.success && st.stats) {
      document.getElementById('e-post-ct').textContent = st.stats.postings ?? 0;
      document.getElementById('e-app-ct').textContent = st.stats.applications ?? 0;
      document.getElementById('e-pend-ct').textContent = st.stats.pending ?? 0;
      document.getElementById('e-acc-ct').textContent = st.stats.accepted ?? 0;
    }

    // Only fill company profile fields from DB - never hardcode
    document.getElementById('cp-name').value = profile.company_name || '';
    document.getElementById('cp-email').value = profile.email || '';
    document.getElementById('cp-industry').value = profile.industry || '';
    document.getElementById('cp-web').value = profile.website || '';
    document.getElementById('cp-desc').value = profile.description || '';

    renderEHome();
    renderEPostings();
    renderEApps();
  } catch(err) {
    console.error('Employer dashboard load error:', err);
  }
}

// ===================== NAVIGATION =====================
function ePg(pgId, navId) {
  document.querySelectorAll('#e-home, #e-postings, #e-new, #e-apps, #e-profile').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById(pgId).classList.add('active');
  document.getElementById(navId).classList.add('active');
  if (pgId === 'e-home') renderEHome();
  if (pgId === 'e-postings') renderEPostings();
  if (pgId === 'e-apps') renderEApps();
}

// ===================== HOME =====================
function renderEHome() {
  document.getElementById('e-home-list').innerHTML = postings.map(i =>
    `<div class="flex justify-between items-center" style="padding:12px 0; border-bottom:1px solid var(--border);">
      <div>
        <div class="fw-500">${i.title}</div>
        <div class="text-sm text-muted mt-4">${i.domain} &middot; ${i.duration} &middot; ${i.applicant_count || 0} applicant(s)</div>
      </div>
      <span class="tag green">Active</span>
    </div>`
  ).join('') || '<p class="text-muted center" style="padding:1rem;">No postings yet.</p>';
}

// ===================== POSTINGS =====================
function renderEPostings() {
  const el = document.getElementById('e-post-list');
  const none = document.getElementById('no-posts');
  if (!postings.length) { el.innerHTML = ''; none.style.display = 'block'; return; }
  none.style.display = 'none';
  el.innerHTML = postings.map(i =>
    `<div class="intern-card">
      <div class="ic-company">${i.company_name}</div>
      <div class="ic-title">${i.title}</div>
      <div class="ic-meta">
        <span>&#128188; ${i.domain}</span><span>&#128197; ${i.duration}</span>
        <span class="ic-stipend">PKR ${parseInt(i.stipend).toLocaleString()}/month</span>
        <span>&#128101; ${i.applicant_count || 0} applicant(s)</span>
      </div>
      <div class="ic-desc">${i.description}</div>
      <div class="ic-skills">${i.skills.split(',').map(s => `<span class="tag gray">${s.trim()}</span>`).join(' ')}</div>
      <div class="ic-actions mt-8">
        <button class="btn sm red" onclick="deletePost(${i.id})">Delete posting</button>
        <span class="tag green">Active</span>
      </div>
    </div>`
  ).join('');
}

async function deletePost(id) {
  if (!confirm('Delete this internship posting?')) return;
  const res = await api('delete_posting', { id });
  if (res.success) {
    const refresh = await api('get_postings');
    postings = refresh.postings;
    renderEPostings();
    refreshStats();
  }
}

async function postJob() {
  const title = document.getElementById('ni-title').value.trim();
  const domain = document.getElementById('ni-domain').value;
  const dur = document.getElementById('ni-dur').value.trim();
  const stipend = parseInt(document.getElementById('ni-stipend').value) || 0;
  const skills = document.getElementById('ni-skills').value.trim();
  const desc = document.getElementById('ni-desc').value.trim();
  const website = document.getElementById('ni-website').value.trim();
  const err = document.getElementById('ni-err');
  const ok = document.getElementById('ni-ok');
  const btn = document.getElementById('btn-post');

  if (!title || !domain || !dur || !desc) {
    err.textContent = 'Please fill all required fields (title, domain, duration, description).';
    err.style.display = 'block'; return;
  }
  err.style.display = 'none';
  btn.disabled = true;
  btn.textContent = 'Publishing...';

  const res = await api('add_posting', { title, domain, duration: dur, stipend, skills, description: desc, website });
  if (res.success) {
    ['ni-title', 'ni-dur', 'ni-stipend', 'ni-skills', 'ni-desc', 'ni-website'].forEach(id => document.getElementById(id).value = '');
    document.getElementById('ni-domain').value = '';
    ok.style.display = 'block';
    const refresh = await api('get_postings');
    postings = refresh.postings;
    refreshStats();
    setTimeout(() => {
      ok.style.display = 'none';
      btn.disabled = false;
      btn.textContent = 'Publish Internship';
      ePg('e-postings', 'en-post');
    }, 800);
  } else {
    err.textContent = res.error || 'Failed to post.';
    err.style.display = 'block';
    btn.disabled = false;
    btn.textContent = 'Publish Internship';
  }
}

// ===================== APPLICATIONS =====================
function renderEApps() {
  const el = document.getElementById('e-apps-body');
  if (!applications.length) {
    el.innerHTML = '<tr><td colspan="6" class="text-muted center" style="padding:2rem;">No applications yet.</td></tr>';
    return;
  }
  const colorMap = { Pending: 'blue', Accepted: 'green', Rejected: 'red' };
  el.innerHTML = applications.map(a => {
    const sc = a.quiz_score || 0;
    const hasProjects = a.selected_project_ids && a.selected_project_ids.length > 0;
    const hasCerts    = a.selected_cert_ids    && a.selected_cert_ids.length > 0;
    return `<tr>
      <td>
        <div class="fw-500">${a.full_name}</div>
        <div class="text-sm text-muted">${a.email || ''}</div>
        ${a.phone ? '<div class="text-sm text-muted">' + a.phone + '</div>' : ''}
      </td>
      <td>${a.internship_title}</td>
      <td>
        <span class="tag ${sc >= 80 ? 'green' : 'amber'}">${sc}%</span>
        ${hasProjects ? `<span class="tag blue" style="font-size:10px;margin-left:3px;cursor:pointer;" onclick="viewStudent(${a.id})">&#128193; Projects</span>` : ''}
        ${hasCerts    ? `<span class="tag teal" style="font-size:10px;margin-left:3px;cursor:pointer;" onclick="viewStudent(${a.id})">&#127942; Certs</span>`   : ''}
      </td>
      <td><span class="tag ${colorMap[a.status] || 'gray'}">${a.status}</span></td>
      <td style="text-align:center;">
        <button class="btn sm blue" onclick="viewStudent(${a.id})" style="white-space:nowrap;">&#128100; View Profile</button>
      </td>
      <td style="text-align:center;">
        <div style="display:flex;gap:6px;justify-content:center;align-items:center;flex-wrap:wrap;">
          ${a.status !== 'Accepted' ? `<button class="btn sm teal" onclick="setStatus(${a.id}, 'Accepted')">&#10003; Accept</button>` : ''}
          ${a.status !== 'Rejected' ? `<button class="btn sm red"  onclick="setStatus(${a.id}, 'Rejected')">&#10007; Reject</button>`  : ''}
        </div>
      </td>
    </tr>`;
  }).join('');
}

async function viewStudent(appId) {
  const appData = applications.find(a => a.id == appId);
  if (!appData) return;

  // Fetch full student profile
  let res;
  try {
    res = await api('get_student_profile', { student_id: appData.student_id });
  } catch(e) {
    alert('Network error loading student profile. Please try again.');
    return;
  }
  if (!res || !res.success) {
    alert('Could not load student profile: ' + (res?.error || 'Unknown error'));
    return;
  }

  const s = res.student;
  document.getElementById('ms-name').textContent     = s.full_name || '';
  document.getElementById('ms-initials').textContent = (s.full_name || 'ST').split(' ').map(w => w[0]).join('').slice(0,2).toUpperCase();
  document.getElementById('ms-fullname').textContent = s.full_name || '';
  document.getElementById('ms-email').textContent    = s.email || '';
  document.getElementById('ms-location').textContent = s.location || 'Location not set';
  const resumeEl = document.getElementById('ms-resume');
  if (s.resume_url) { resumeEl.href = s.resume_url; resumeEl.style.display = ''; }
  else { resumeEl.style.display = 'none'; }

  // Cover letter
  const coverWrap = document.getElementById('ms-cover-wrap');
  if (appData.cover_letter) {
    coverWrap.style.display = '';
    document.getElementById('ms-cover').textContent = appData.cover_letter;
  } else { coverWrap.style.display = 'none'; }

  // Quiz scores
  const qEl = document.getElementById('ms-quiz-scores');
  qEl.innerHTML = (res.quiz_scores || []).length
    ? res.quiz_scores.map(q => `<span class="tag ${q.score >= 80 ? 'green' : 'amber'}">${q.domain}: ${q.score}%</span>`).join('')
    : '<span class="text-muted" style="font-size:13px;">No quiz taken yet</span>';

  // Skills
  const skEl = document.getElementById('ms-skills');
  skEl.innerHTML = (res.skills || []).length
    ? res.skills.map(sk => `<span class="tag gray">${sk.name}</span>`).join('')
    : '<span class="text-muted" style="font-size:13px;">No skills added</span>';

  // Submitted Projects (only selected ones)
  const selProjIds = (appData.selected_project_ids || '').split(',').map(x => parseInt(x)).filter(Boolean);
  const allProjects = res.projects || [];
  const submittedProjects = selProjIds.length
    ? allProjects.filter(p => selProjIds.includes(parseInt(p.id)))
    : allProjects;
  const prEl = document.getElementById('ms-projects');
  prEl.innerHTML = submittedProjects.length
    ? submittedProjects.map(p =>
        '<div style="border:1.5px solid var(--border);border-radius:9px;padding:10px 14px;display:flex;justify-content:space-between;align-items:center;gap:10px;">' +
        '<div style="flex:1;">' +
        '<div style="font-weight:600;font-size:14px;">' + p.title + '</div>' +
        (p.tech_stack ? '<div style="font-size:12px;color:var(--muted);margin-top:2px;">Stack: ' + p.tech_stack + '</div>' : '') +
        (p.description ? '<div style="font-size:13px;margin-top:4px;color:var(--text);">' + p.description + '</div>' : '') +
        '</div>' +
        (p.project_url ? '<a href="' + p.project_url + '" target="_blank" class="btn sm blue" style="font-size:11px;white-space:nowrap;flex-shrink:0;">View &#8599;</a>' : '<span style="font-size:11px;color:var(--muted);">No URL</span>') +
        '</div>'
      ).join('')
    : '<span class="text-muted" style="font-size:13px;">No projects submitted</span>';

  // Submitted Certs (only selected ones)
  const selCertIds = (appData.selected_cert_ids || '').split(',').map(x => parseInt(x)).filter(Boolean);
  const allCerts = res.certs || [];
  const submittedCerts = selCertIds.length
    ? allCerts.filter(c => selCertIds.includes(parseInt(c.id)))
    : allCerts;
  const ceEl = document.getElementById('ms-certs');
  ceEl.innerHTML = submittedCerts.length
    ? submittedCerts.map(c =>
        '<div style="border:1.5px solid var(--border);border-radius:9px;padding:10px 14px;display:flex;justify-content:space-between;align-items:center;gap:10px;">' +
        '<div style="flex:1;"><div style="font-weight:600;font-size:14px;">' + c.title + '</div>' +
        '<div style="font-size:12px;color:var(--muted);">' + c.issuer + (c.issue_date ? ' · ' + c.issue_date : '') + '</div></div>' +
        (c.cert_url ? '<a href="' + c.cert_url + '" target="_blank" class="btn sm blue" style="font-size:11px;white-space:nowrap;flex-shrink:0;">View &#8599;</a>' : '<span style="font-size:11px;color:var(--muted);">No URL</span>') +
        '</div>'
      ).join('')
    : '<span class="text-muted" style="font-size:13px;">No certificates submitted</span>';

  // Action buttons - centered
  const actEl = document.getElementById('ms-actions');
  const colorMap2 = { Pending: 'blue', Accepted: 'green', Rejected: 'red' };
  const app = applications.find(a => a.id == appId);
  const status = app ? app.status : 'Pending';
  actEl.innerHTML =
    (status !== 'Accepted' ? `<button class="btn teal" onclick="setStatus(${appId},'Accepted');closeM('m-student')">&#10003; Accept</button>` : '') +
    (status !== 'Rejected' ? `<button class="btn red"  onclick="setStatus(${appId},'Rejected');closeM('m-student')">&#10007; Reject</button>`  : '') +
    `<span class="tag ${colorMap2[status] || 'gray'}" style="align-self:center;">Currently: ${status}</span>`;

  openM('m-student');
}

function eApi(action, params = {}) {
  return fetch('../php/employer-api.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ action, ...params })
  }).then(r => r.json()).catch(() => ({ success: false }));
}

async function setStatus(appId, status) {
  const res = await api('update_application_status', { application_id: appId, status });
  if (res.success) {
    const refresh = await api('get_applications');
    applications = refresh.applications;
    renderEApps();
    refreshStats();
  }
}

// ===================== PROFILE =====================
async function saveCompanyProfile() {
  const company = document.getElementById('cp-name').value;
  const email = document.getElementById('cp-email').value;
  const industry = document.getElementById('cp-industry').value;
  const website = document.getElementById('cp-web').value;
  const desc = document.getElementById('cp-desc').value;

  const res = await api('update_profile', { company_name: company, email, industry, website, description: desc });
  if (res.success) {
    profile.company_name = company;
    document.getElementById('en-uname').textContent = company;
    const msg = document.getElementById('cp-ok');
    msg.style.display = 'block';
    setTimeout(() => msg.style.display = 'none', 2500);
  }
}

async function refreshStats() {
  const st = await api('get_stats');
  if (st && st.success && st.stats) {
    document.getElementById('e-post-ct').textContent = st.stats.postings ?? 0;
    document.getElementById('e-app-ct').textContent = st.stats.applications ?? 0;
    document.getElementById('e-pend-ct').textContent = st.stats.pending ?? 0;
    document.getElementById('e-acc-ct').textContent = st.stats.accepted ?? 0;
  }
  renderEHome();
}

// ===================== MODALS =====================
function openM(id) { document.getElementById(id).classList.add('open'); }
function closeM(id) { document.getElementById(id).classList.remove('open'); }
document.querySelectorAll('.overlay').forEach(o => {
  o.addEventListener('click', e => { if (e.target === o) o.classList.remove('open'); });
});
